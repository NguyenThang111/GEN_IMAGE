"""Keep every source text available to both vector and component renderers."""
from copy import deepcopy
from render_schematic import flatten, text_box

SH_POWER_CAPTIONS = {
 ('TIẾP ĐIỂM',301):'starter-feed', ('RƠ LE',315):'starter-feed',
 ('KHỞI ĐỘNG/SẠC',329):'starter-feed',
 ('TIẾP ĐIỂM RƠ LE KHỞI ĐỘNG/SẠC',109):'starter-supply',
 ('BỘ SẠC USB',162):'usb-output', ('CÔNG TẮC CÒI',405):'horn-load',
 ('CỤM ĐÈN PHA LED',467):'head-load', ('RƠ LE XI NHAN',654):'flasher-load',
}

def enrich_diagram_text(diagram):
 d=deepcopy(diagram)
 if not d.get('drawing'):return d
 ids={c['id'] for c in d['components']}
 if {'starter-feed','starter-supply','usb-output'}.issubset(ids):
  for e in d['drawing']['elements']:
   owner=SH_POWER_CAPTIONS.get((e.get('text'),e.get('y')))
   if e.get('kind')=='text' and e.get('owner')=='annotation' and owner:
    e['owner']=owner;e['role']='component-label'
 for c in d['components']:
  if c.get('symbolType',c['type'])!='annotationBox' and c['id']!='legend':continue
  for e in d['drawing']['elements']:
   if e.get('kind')!='text' or e.get('owner')!=c['id']:continue
   b=text_box(e)
   # Align visible glyphs, including the left bearing of Vietnamese Đ.
   shift=c['x']+c['width']/2-(b[0]+b[2])/2 if e.get('anchor')=='middle' else c['x']+10-b[0]
   e['x']=round(e['x']+shift,3)
 flat=flatten(d)
 for c in d['components']:
  own=[deepcopy(e) for e in flat if e.get('owner')==c['id'] and e.get('role') not in ('wire','wire-label')]
  texts=[e for e in own if e['kind']=='text']
  paths=[e for e in own if e['kind']=='path']
  kind='note-box' if c.get('symbolType',c['type'])=='annotationBox' or c['id']=='legend' else ('load-list' if c.get('symbolType',c['type'])=='loadGroup' or c.get('combLabels') else 'component')
  c['textLayout']={'kind':kind,'texts':texts,'paths':paths}
  if kind=='note-box':c['textLayout']['padding']=10
  if kind in ('load-list','note-box'):
   if not texts:raise ValueError('Missing text: '+c['id'])
   c['label']='\n'.join(e['text'] for e in texts)
  elif not c.get('label'):
   names=[e['text'] for e in texts if e.get('role')=='component-label' or (any(ch.isalpha() for ch in e['text']) and len(e['text'])>4)]
   if names:c['label']='\n'.join(names)
 for w in d['wires']:
  # A component and wire can share an ID. Classify by role first.
  texts=[deepcopy(e) for e in flat if e.get('owner')==w['id'] and e.get('role')=='wire-label' and e['kind']=='text']
  w['labels']=texts
 wireids={w['id'] for w in d['wires']}
 loose=[deepcopy(e) for e in flat if e.get('owner') not in ids and not(e.get('owner') in wireids and e.get('role') in ('wire','wire-label'))]
 d['annotations']=[{'id':'source-annotations','elements':loose}] if loose else []
 return d

def audit_diagram_text(d):
 items=flatten(d);texts=[e for e in items if e['kind']=='text']
 errors=[];notes=[]
 for e in texts:
  b=text_box(e)
  if b[0]<-0.1 or b[1]<-0.1 or b[2]>d['canvas']['width']+0.1 or b[3]>d['canvas']['height']+0.1:errors.append({'code':'text-canvas','text':e['text'],'bounds':b})
 for c in d['components']:
  layout=c.get('textLayout',{})
  if layout.get('kind') not in ('load-list','note-box'):continue
  if not c['label'].strip() or not layout.get('texts'):errors.append({'code':'empty-text','owner':c['id']})
  if layout['kind']=='note-box':
   pad=layout['padding'];frame=(c['x'],c['y'],c['x']+c['width'],c['y']+c['height'])
   for i,e in enumerate(layout['texts']):
    b=text_box(e)
    if b[0]<frame[0]+pad-0.5 or b[2]>frame[2]-pad+0.5 or b[1]<frame[1]+3 or b[3]>frame[3]-3:errors.append({'code':'note-padding','owner':c['id'],'text':e['text'],'bounds':b,'frame':frame})
    if e.get('anchor')!=('middle' if i==0 else 'start'):errors.append({'code':'note-alignment','owner':c['id'],'text':e['text']})
   notes.append({'owner':c['id'],'lines':len(layout['texts']),'padding':pad,'titleAnchor':'middle','bodyAnchor':'start'})
 projected=[e for c in d['components'] for e in c.get('textLayout',{}).get('texts',[])]+[e for w in d['wires'] for e in w.get('labels',[])]+[e for a in d.get('annotations',[]) for e in a['elements'] if e['kind']=='text']
 from collections import Counter
 sig=lambda e:(e['text'],e['x'],e['y'],e.get('size',14),e.get('anchor','middle'),e.get('rotate',0))
 if Counter(map(sig,texts))!=Counter(map(sig,projected)):errors.append({'code':'lost-or-duplicated-text'})
 return {'textCount':len(texts),'projectedTextCount':len(projected),'noteBoxes':notes,'errors':errors}
