"""Map known symbol families to the original Studio component contract.
Detailed drawings and electrical topology remain byte-for-byte equivalent as JSON.
Unknown families are rejected, never guessed.
"""
from copy import deepcopy
BASE_TYPES = set("battery fuse relay switch selectorSwitch scu ecm acg connector ground junction horn flasher diode lamp gauge sensor ignitionCoil sparkPlug motor injector pump valve device".split())
ALIASES = {"loadGroup":"device","sender":"sensor","connectorBox":"connector","pinout":"connector","cluster":"device","rotor":"device","speaker":"horn","assembly":"device","coil":"device","remote":"device","annotationBox":"device","solenoid":"device","buzzer":"horn"}
def compatible_diagram(diagram):
    result=deepcopy(diagram); changes=[]
    for c in result["components"]:
        original=c["type"]
        if original in BASE_TYPES: continue
        if original in ("led","indicator"):
            mapped="lamp" if len(c["terminals"]) >= 2 else "device"
        elif original in ALIASES: mapped=ALIASES[original]
        else: raise ValueError("Unsupported component family: "+str(original))
        c.setdefault("symbolType",original)
        c["type"]=mapped
        changes.append(dict(id=c["id"],before=original,after=mapped))
    return result, changes
