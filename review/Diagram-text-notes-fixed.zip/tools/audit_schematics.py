"""Legacy internal consistency checks only; NOT source-image verification.

CLI now delegates to diagram_check/check.py. The legacy audit() API is retained
for old preview pages but its zero counts never certify schematic accuracy.
"""
import json
import math
from pathlib import Path
from render_schematic import flatten,text_box

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'File JSON chuẩn'/'01.AirBlade-2011-2012'

def overlaps(a,b,pad=0):
    return a[0]<b[2]+pad and a[2]>b[0]-pad and a[1]<b[3]+pad and a[3]>b[1]-pad

def hits_segment(box,a,b,pad=0):
    x0,y0,x1,y1=box; x0-=pad;y0-=pad;x1+=pad;y1+=pad
    if not overlaps((min(a[0],b[0])-.01,min(a[1],b[1])-.01,max(a[0],b[0])+.01,max(a[1],b[1])+.01),(x0,y0,x1,y1)):return False
    dx=b[0]-a[0];dy=b[1]-a[1];low=0;high=1
    for p,q in [(-dx,a[0]-x0),(dx,x1-a[0]),(-dy,a[1]-y0),(dy,y1-a[1])]:
        if abs(p)<1e-9:
            if q<0:return False
        elif p<0:low=max(low,q/p)
        else:high=min(high,q/p)
    return low<=high

def audit(d):
    errors=[]; warnings=[]; refs={}
    seen=set()
    for c in d['components']:
        if c['id'] in seen:errors.append('Duplicate component '+c['id'])
        seen.add(c['id'])
        for t in c['terminals']:refs[(c['id'],t['id'])]=(t['x'],t['y'])
    for w in d['wires']:
        for key,idx in [('from',0),('to',-1)]:
            ref=w[key];pt=refs.get((ref['componentId'],ref['terminalId']))
            if pt is None:errors.append('Unknown terminal '+w['id']+' '+key);continue
            end=w['points'][idx]
            if math.dist(pt,(end['x'],end['y']))>.01: errors.append('Endpoint mismatch '+w['id']+' '+key)
    shapes=flatten(d);labels=[e for e in shapes if e['kind']=='text']
    boxes=[text_box(e) for e in labels]
    for i,(e,b) in enumerate(zip(labels,boxes)):
        ref=f'{e.get("owner","annotation")}:{e["text"]}'
        if b[0]<-.5 or b[1]<-.5 or b[2]>d['canvas']['width']+.5 or b[3]>d['canvas']['height']+.5:warnings.append(dict(kind='out-of-canvas',label=ref,box=b))
        for j in range(i):
            if overlaps(b,boxes[j],.3):warnings.append(dict(kind='text-text',label=ref,other=f'{labels[j].get("owner","annotation")}:{labels[j]["text"]}'))
        if e.get('role') not in ('component-label','wire-label'):continue
        for c in d['components']:
            if c['type'] in ('junction','ground'):continue
            box=(c['x'],c['y'],c['x']+c['width'],c['y']+c['height'])
            if overlaps(b,box,1):warnings.append(dict(kind='text-component',label=ref,other=c['id']))
        for w in d['wires']:
            pts=[(p['x'],p['y']) for p in w['points']]
            if any(hits_segment(b,a,z,3.5 if 'PGM-FI' not in d['circuitTitle'] else 2) for a,z in zip(pts,pts[1:])):
                warnings.append(dict(kind='text-wire',label=ref,other=w['id']))
    return dict(errors=errors,layoutWarnings=warnings,components=len(d['components']),wires=len(d['wires']),textItems=len(labels),certifiesSourceAccuracy=False,scope='legacy-internal-consistency-only')

if __name__=='__main__':
    import subprocess
    import sys
    print('Use independent source checker; old zero counts did not certify accuracy.',flush=True)
    sys.exit(subprocess.call([sys.executable,str(Path(__file__).with_name('diagram_check')/'check.py'),*sys.argv[1:]]))
