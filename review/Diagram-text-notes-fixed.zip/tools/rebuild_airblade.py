"""Review/rebuild the ten supplied AirBlade circuits, preserving legacy IDs.

Run from anywhere: python tools/rebuild_airblade.py
Original files are read only. Outputs go to File JSON chuẩn/01.AirBlade-2011-2012.
"""
import copy
import json
import math
from pathlib import Path
from schematic_symbols import library, line, rect, ellipse, text, coil, INK, PALE, GREY
from render_schematic import render, text_box

ROOT=Path(__file__).resolve().parents[1]
INPUT=ROOT/'FILE GEN JSON'/'01.AirBlade-2011-2012'
OUTPUT=ROOT/'File JSON chuẩn'/'01.AirBlade-2011-2012'
PALETTE={'R':'#dc1d39','G':'#0ec05b','Bl':'#444444','W':'#ffffff','Y':'#fbfe18','Bu':'#12bee7','Lb':'#95ddf7','Br':'#a58e72','Gr':'#a9afaf','O':'#f3a455','Lg':'#aadc4a','P':'#f2a4b4'}
PALETTE_SAMPLES={
    'R':('08-37-27',310,419),'G':('08-37-27',174,470),'Bl':('08-37-27',810,494),'Br':('08-37-27',1225,420),'Lg':('08-37-27',1450,419),
    'P':('08-38-12 (1)',571,320),'O':('08-38-12 (1)',1200,405),'Lb':('08-38-12 (1)',1200,505),'Bu':('08-38-12 (1)',1200,634),'Gr':('08-38-12 (1)',610,456),'Y':('08-37-20',326,590)}
SYMBOLS=library()

def read(name): return json.loads((INPUT/name).read_text(encoding='utf-8-sig'))
def comp(d,cid): return next(c for c in d['components'] if c['id']==cid)
def wire(d,wid): return next(w for w in d['wires'] if w['id']==wid)
def points(*pairs): return [dict(x=x,y=y) for x,y in pairs]
def add_comp(d,cid,typ,x,y,w,h,label,terms=()):
    c=dict(id=cid,type=typ,x=x,y=y,width=w,height=h,label=label,terminals=[dict(id=t[0],x=t[1],y=t[2],**({'label':t[3]} if len(t)>3 else {})) for t in terms]); d['components'].append(c); return c
def add_wire(d,wid,a,b,code,pts):
    ca,ta=a.rsplit('.',1); cb,tb=b.rsplit('.',1)
    w=dict(id=wid,**{'from':dict(componentId=ca,terminalId=ta),'to':dict(componentId=cb,terminalId=tb)},code=code,points=points(*pts),state='controlled'); d['wires'].append(w); return w
def note(d,s,x,y,size=14,anchor='middle',rotate=0,owner=None):
    e=text(s,x,y,size,anchor,rotate); e['role']='annotation'; e['owner']=owner or 'annotation'; d.setdefault('extraDrawing',[]).append(e)
def caption(c,s,x,y,size=14,anchor='middle',rotate=0):
    c.setdefault('captions',[]).append(text(s,x,y,size,anchor,rotate))
def use(e,name,x,y,w,h,nw=100,nh=100,rotation=0,owner=None):
    if rotation==0: m=[w/nw,0,0,h/nh,x,y]
    elif rotation==90: m=[0,h/nw,-w/nh,0,x+w,y]
    elif rotation==-90: m=[0,-h/nw,w/nh,0,x,y+h]
    elif rotation==180: m=[-w/nw,0,0,-h/nh,x+w,y+h]
    e.append(dict(kind='use',symbol=name,matrix=m,owner=owner))

def patch_power():
    # The file called night lighting actually traced the power-distribution image.
    d=read('thang-night-lighting.schema.json')
    d.update(id=read('Mạch cấp nguồn.json')['id'],circuitTitle='Mạch cấp nguồn')
    comp(d,'battery').update(width=91)
    wire(d,'battery-ground-wire')['points']=points((202,459),(202,412),(161,412),(161,499))
    # Replace misplaced loose junction labels with the three comb connectors seen in the source.
    prefixes=('answer-back-output-','turn-horn-bus-','engine-bus-')
    remove={c['id'] for c in d['components'] if c['id'].startswith(prefixes)}
    d['components']=[c for c in d['components'] if c['id'] not in remove]
    d['wires']=[w for w in d['wires'] if not w['id'].startswith(('turn-horn-output-bus-','engine-output-bus-'))]
    for cid,x,y,labels,ys in [
        ('answer-loads',644,217,['HỘP ĐỊNH VỊ XE','ĐÈN LED Ổ KHÓA ĐIỆN','ĐÈN LED THÙNG YÊN'],[217,237,257]),
        ('turn-loads',1292,334,['CÔNG TẮC PHANH TRƯỚC/SAU','CÔNG TẮC CÒI','RƠ LE XI NHAN','ĐÈN NỀN ĐỒNG HỒ','ĐÈN BÁO LỖI','ĐÈN CẢNH BÁO NHIỆT ĐỘ NƯỚC LÀM MÁT','HỘP ĐỊNH VỊ XE','CÔNG TẮC ĐÈN ĐÊM','ĐỒNG HỒ BÁO XĂNG'],[334,354,375,396,416,436,457,479,501]),
        ('engine-loads',1292,598,['ECM','KIM PHUN','MÔ-BIN SƯỜN','BƠM XĂNG','DLC','RƠ LE KHỞI ĐỘNG','VAN CẦM CHỪNG NHANH'],[598,618,638,658,678,698,718])]:
        c=add_comp(d,cid,'connector',x,y,31,ys[-1]-y,'', [('in',x,254 if cid=='answer-loads' else (336 if cid=='turn-loads' else 602))])
        c['combLabels']=list(zip(labels,ys))
    for wid,cid in [('answer-back-output-wire','answer-loads'),('turn-horn-output','turn-loads'),('engine-bl-bus','engine-loads')]:
        wire(d,wid)['to']=dict(componentId=cid,terminalId='in')
    comp(d,'night-light-switch').update(type='connector'); comp(d,'night-light-switch')['arrow']=True
    d['reviewChanges']=['Thay bản cấp nguồn 1600×902 tham chiếu JPEG không có bằng bản tọa độ đúng ảnh PNG 1687×952.', 'Sửa đường mass ắc quy; sửa các giắc chia tải và nhãn bị lệch.', 'Giữ nguyên chuyển màu R/Bl → R/W tại tụ như ảnh.']
    return d

def patch_existing(name):
    d=read(name); d['reviewChanges']=[]
    if 'định vị' in name:
        d['circuitTitle']='Mạch điện xác định vị trí xe'
        d['reviewChanges'] += ['Sửa tiêu đề báo tốc độ thành xác định vị trí xe; giữ ID cũ để không làm đứt liên kết dữ liệu.', 'Bổ sung hình giắc 10P, số chân 1–10 và nhãn đầu nối.', 'Giữ chân 9 trên hình giắc tham chiếu; không tự thêm dây vào chân không được vẽ.']
        comp(d,'horn')['symbol']='speaker'
        comp(d,'led-seat')['symbol']='led-single'; comp(d,'led-key')['symbol']='led-single'
        c=comp(d,'locator'); c['label']='HỘP\nĐỊNH VỊ XE'
        add_comp(d,'locator-pinout','connector',1271,727,193,108,'ĐẦU NỐI 10P PHÍA BỘ TÌM XE/CỰC LỒI')['symbol']='pinout'
        note(d,'10P/Bl',1147,701,19,'start')
    if 'phanh' in name:
        comp(d,'brake-tail-lamp')['symbol']='led-panel'
        w=wire(d,'resistor-ground-wire'); w['code']='G'
        d['reviewChanges'] += ['Sửa dây từ điện trở xuống mass thành G màu xanh đúng ảnh.', 'Vẽ lại cụm LED ba nhánh và ghi đủ 10Ω 20W.']
    if 'fuel-indicator' in name:
        d['extraDrawing']=[rect(1405,845,211,57,'white',width=2),line([[1418,875],[1603,875]])]
        note(d,'GHI CHÚ',1510,868,17); note(d,'DUNG TÍCH BÌNH XĂNG: 4,5 lít',1510,895,13)
        d['reviewChanges'] += ['Bổ sung ghi chú dung tích 4,5 lít bị bỏ sót; vẽ đủ F/E, biểu tượng xăng và phao.']
    if 'ignition' in name:
        wire(d,'w-green-ground')['points']=points((1339,369),(1339,642),(1294,695))
        wire(d,'w-ecm-10-ground')['points']=points((1201,679),(1201,462),(1249,462),(1249,641),(1294,695))
        comp(d,'side-stand-switch')['symbol']='stand-switch'
        d['reviewChanges'] += ['Sửa đường mass chéo bị biến thành bậc thang.', 'Vẽ đủ răng rôto CKP, cuộn CKP, mô-bin, bugi và nhãn chân ECM.']
    if 'starting' in name:
        wire(d,'w-starter-feed')['points']=points((300,336),(320,293),(372,293),(372,462))
        wire(d,'w-battery-motor')['points']=points((241,345),(216,299),(188,299),(188,645),(258,645),(305,693))
        wire(d,'w-motor-lug-ground')['points']=points((438,693),(486,645),(557,645),(557,760))
        d['reviewChanges'] += ['Sửa các đường dây chéo ở ắc quy và mô tơ bị vẽ thành bậc thang.', 'Bổ sung đủ số chân ECM 33, 1, 7, 29, 25.']
    if 'nguyên lý' in name:
        d['circuitTitle']='Sơ đồ nguyên lý hệ thống phun xăng điện tử (PGM-FI)'
        ecm=comp(d,'ecm')
        # In the screenshot THL = pin 5, O₂ = pin 3. The old trace swapped them.
        for t in ecm['terminals']:
            if t['id']=='p3': t.update(id='p5',label='5 THL')
            elif t['id']=='p5': t.update(id='p3',label='3 O₂')
            elif t['id']=='p33':t['label']='33 S/RELAY'
            elif t['id']=='p22':t['label']='22 FI WARN'
            elif t['id']=='p18':t['label']='18 TW WARN'
        wire(d,'w-tp-signal')['from']['terminalId']='p5'
        wire(d,'w-oxygen-signal')['from']['terminalId']='p3'
        add_wire(d,'w-battery-starter','battery.pos','starter-relay.contact-in','R',[(267,788),(222,807),(157,807),(157,140),(860,140)])
        add_wire(d,'w-pg2-ground','ecm.p10','ecm-ground.in','G/Bl',[(1226,614),(1226,650),(1307,675)])
        add_wire(d,'w-pg1-ground','ecm.p9','ecm-ground.in','G',[(1252,614),(1252,639),(1307,675)])
        comp(d,'spark-plug')['terminals']=[dict(id='ht',x=1014,y=343)]
        add_wire(d,'w-coil-ht','ignition-coil.ht','spark-plug.ht','',[(1014,343),(1014,343)])
        # Keep white/black DLC's power lead visible where it passes across the ECM.
        add_comp(d,'ecm-pinout','connector',1467,178,105,199,'ĐẦU NỐI 33P ECM\n(ĐẦU CỰC LỒI PHÍA ECM)')['symbol']='pinout'
        d['reviewChanges'] += ['Sửa tiêu đề Idling Stop thành sơ đồ nguyên lý PGM-FI; giữ ID gốc.', 'Sửa số chân THL 3→5, O₂ 5→3 theo ảnh.', 'Bổ sung dây nguồn trực tiếp ắc quy → rơ le khởi động, hai dây mass PG1/PG2 và nối cao áp mô-bin → bugi.', 'Bổ sung giắc 33P, mã lỗi và bảng ghi chú.']
    return d

def make_night():
    d=read('thang-night-lighting.schema.json'); d['components']=[]; d['wires']=[]
    d['sourceImage']='Screenshot from 2026-09-30 08-37-50.png'
    d['circuitTitle']='Mạch đèn đêm'
    for args in [
        ('battery','battery',199,437,98,71,'ẮC QUY',[('negative',218,437),('positive',276,437)]),
        ('ground-battery','ground',154,482,40,25,'',[('in',174,482)]),
        ('j-r','junction',328,378,8,8,'',[('node',332,382)]),
        ('fuse-main','fuse',393,363,80,37,'CẦU CHÌ (20A) MAIN',[('left',393,382),('right',473,382)]),
        ('fuse-fi','fuse',393,438,80,37,'CẦU CHÌ (10A) FI',[('left',393,456),('right',473,456)]),
        ('ignition-switch','switch',555,430,77,44,'CÔNG TẮC MÁY',[('left',555,456),('right',632,456)]),
        ('main-relay','relay',707,362,76,116,'RƠ LE CHÍNH',[('contact-left',707,382),('contact-right',783,382),('coil-left',707,456),('coil-right',783,456)]),
        ('ecm','ecm',807,547,80,53,'ECM',[('top',847,547)]),
        ('j-ry','junction',829,378,8,8,'',[('node',833,382)]),
        ('fuse-head','fuse',895,294,75,36,'CẦU CHÌ (10A) HEAD LIGHT',[('left',895,312),('right',970,312)]),
        ('fuse-turn','fuse',895,365,75,35,'CẦU CHÌ (10A) TURN...',[('left',895,382),('right',970,382)]),
        ('night-switch','switch',1074,310,76,86,'CÔNG TẮC\nĐÈN ĐÊM',[('in1',1074,338),('out1',1150,338),('in2',1074,382),('out2',1150,382)]),
        ('dimmer','selectorSwitch',1227,302,79,71,'CÔNG TẮC\nPHA CỐT',[('common',1227,338),('upper',1306,320),('lower',1306,354)]),
        ('j-bu','junction',1339,316,8,8,'',[('node',1343,320)]),
        ('high-indicator','lamp',1422,171,102,64,'ĐÈN BÁO PHA',[('feed',1422,195),('return',1422,212)]),
        ('ground-high','ground',1370,245,39,24,'',[('in',1389,245)]),
        ('headlamp','lamp',1422,306,178,71,'ĐÈN PHA COS',[('high',1422,320),('low',1422,354),('return',1422,371)]),
        ('ground-head','ground',1360,405,39,24,'',[('in',1379,405)]),
        ('j-br','junction',1182,474,8,8,'',[('node',1186,478)]),
        ('j-br2','junction',1182,597,8,8,'',[('node',1186,601)]),
        ('position','lamp',1428,455,102,64,'ĐÈN VỊ TRÍ',[('feed',1428,478),('return',1428,495)]),
        ('ground-position','ground',1360,530,39,24,'',[('in',1379,530)]),
        ('license','lamp',1428,578,102,64,'ĐÈN BIỂN SỐ',[('feed',1428,601),('return',1428,618)]),
        ('ground-license','ground',1360,653,39,24,'',[('in',1379,653)]),
        ('tail','lamp',1451,699,43,90,'ĐÈN PHANH/\nĐÈN HẬU',[('feed',1451,720),('return',1451,769)]),
        ('ground-tail','ground',1398,813,39,24,'',[('in',1417,813)])]: add_comp(d,*args)
    for wid,a,b,code,pts in [
        ('battery-ground','battery.negative','ground-battery.in','G',[(218,437),(218,382),(174,382),(174,482)]),
        ('battery-feed','battery.positive','j-r.node','R',[(276,437),(276,382),(332,382)]),
        ('main-feed','j-r.node','fuse-main.left','R',[(332,382),(393,382)]),
        ('fi-feed','j-r.node','fuse-fi.left','R',[(332,382),(332,456),(393,456)]),
        ('main-relay','fuse-main.right','main-relay.contact-left','R/W',[(473,382),(707,382)]),
        ('fi-switch','fuse-fi.right','ignition-switch.left','R/Bl',[(473,456),(555,456)]),
        ('switch-relay','ignition-switch.right','main-relay.coil-left','Bl',[(632,456),(707,456)]),
        ('relay-ecm','main-relay.coil-right','ecm.top','W/Bl',[(783,456),(847,456),(847,547)]),
        ('relay-j','main-relay.contact-right','j-ry.node','R/Y',[(783,382),(833,382)]),
        ('j-head','j-ry.node','fuse-head.left','R/Y',[(833,382),(833,312),(895,312)]),
        ('j-turn','j-ry.node','fuse-turn.left','R/Y',[(833,382),(895,382)]),
        ('head-switch','fuse-head.right','night-switch.in1','Y',[(970,312),(1025,312),(1025,338),(1074,338)]),
        ('turn-switch','fuse-turn.right','night-switch.in2','Bl/Br',[(970,382),(1074,382)]),
        ('switch-dimmer','night-switch.out1','dimmer.common','Bu/W',[(1150,338),(1227,338)]),
        ('dimmer-high','dimmer.upper','j-bu.node','Bu',[(1306,320),(1343,320)]),
        ('high-indicator-feed','j-bu.node','high-indicator.feed','Bu',[(1343,320),(1343,195),(1422,195)]),
        ('head-high','j-bu.node','headlamp.high','Bu',[(1343,320),(1422,320)]),
        ('head-low','dimmer.lower','headlamp.low','W',[(1306,354),(1422,354)]),
        ('high-ground','high-indicator.return','ground-high.in','G',[(1422,212),(1389,212),(1389,245)]),
        ('head-ground','headlamp.return','ground-head.in','G',[(1422,371),(1379,371),(1379,405)]),
        ('switch-brown','night-switch.out2','j-br.node','Br',[(1150,382),(1186,382),(1186,478)]),
        ('position-feed','j-br.node','position.feed','Br',[(1186,478),(1428,478)]),
        ('position-ground','position.return','ground-position.in','G',[(1428,495),(1379,495),(1379,530)]),
        ('brown-trunk','j-br.node','j-br2.node','Br',[(1186,478),(1186,601)]),
        ('license-feed','j-br2.node','license.feed','Br',[(1186,601),(1428,601)]),
        ('license-ground','license.return','ground-license.in','G',[(1428,618),(1379,618),(1379,653)]),
        ('tail-feed','j-br2.node','tail.feed','Br',[(1186,601),(1186,720),(1451,720)]),
        ('tail-ground','tail.return','ground-tail.in','G',[(1451,769),(1417,769),(1417,813)])]: add_wire(d,wid,a,b,code,pts)
    comp(d,'headlamp')['symbol']='headlamp'; comp(d,'tail')['symbol']='led-panel'
    d['reviewChanges']=['Thay nội dung nhầm mạch cấp nguồn bằng mạch đèn đêm đúng ảnh 08-37-50.', 'Vẽ đủ hai tầng công tắc đèn, công tắc pha/cốt, bóng hai sợi đốt, đèn báo pha, vị trí, biển số và đèn hậu.']
    return d

def standard_title(c):
    label=c['label'].upper().replace('…','...')
    if c['type']=='fuse':
        if 'ANSWER' in label: return 'CẦU CHÌ (10A) ANSWER BACK'
        if 'HEAD' in label: return 'CẦU CHÌ (10A) HEAD LIGHT'
        if 'TURN' in label or 'HORN' in label: return 'CẦU CHÌ (10A) TURN,HORN...'
        if 'MAIN' in label: return 'CẦU CHÌ (20A) MAIN'
        return 'CẦU CHÌ (10A) FI'
    return label.replace('ĐI-ỐT','ĐI-ỐT')

def set_captions(d):
    overview='PGM-FI' in d['circuitTitle']
    for c in d['components']:
        x,y,w,h=c['x'],c['y'],c['width'],c['height']; typ=c['type']; cid=c['id']
        if typ in ('junction','ground','ecm','battery','pinout') or cid=='locator': continue
        if typ=='connector': continue
        title=standard_title(c)
        if cid in ('load-resistor','resistor'): title='ĐIỆN TRỞ\n10Ω 20W'
        if cid=='ckp-rotor': continue
        if 'capacitor' in cid: title='TỤ ĐIỆN'
        if 'coil' in cid: title='MÔ-BIN\nSƯỜN'
        if cid=='fuel-sender': title='PHAO XĂNG'
        if cid=='regulator': title='TIẾT CHẾ/\nCHỈNH LƯU'
        if cid=='horn' and 'định vị' in d['circuitTitle']: title='CÒI ĐIỆN TỬ'
        if overview: continue
        if cid=='regulator': continue
        if cid in ('capacitor','spark-plug','ignition-coil'):
            xx,yy,anchor=x+w+5,y+h*.5,'start'
        elif cid in ('load-resistor',): xx,yy,anchor=x-10,y+h*.5,'end'
        elif cid=='resistor': xx,yy,anchor=x+w+10,y+h*.5,'start'
        elif cid=='relay-starter': xx,yy,anchor=x+w+8,y+h*.5,'start'; title='RƠ LE\nKHỞI ĐỘNG'
        elif cid=='switch-brake-rear': xx,yy,anchor=x-8,y+h*.5,'end';title='CÔNG TẮC\nPHANH SAU'
        elif cid=='switch-brake-front': xx,yy,anchor=x+w+6,y+h*.5,'start';title='CÔNG TẮC\nPHANH TRƯỚC'
        elif cid=='brake-tail-lamp':
            caption(c,'ĐÈN PHANH/',x+w+23,y+10,14,'start',90);caption(c,'ĐÈN HẬU',x+w+7,y+15,14,'start',90);continue
        elif cid in ('lamp-left','lamp-right'):
            xx,yy,anchor=1556,y+h*.5-4,'middle'; title='ĐÈN\nXI NHAN '+('TRÁI' if cid=='lamp-left' else 'PHẢI')
        elif cid=='horn' and 'định vị' in d['circuitTitle']: xx,yy,anchor=x+w+16,y+h*.55,'start'
        elif cid in ('fuel-sender','acg','motor-starter','rear-brake-switch') or (cid=='side-stand-switch'):
            xx,yy,anchor=x+w/2,y+h+22,'middle'
            if cid=='motor-starter': yy=880; title='MÔ TƠ KHỞI ĐỘNG'
            if cid=='side-stand-switch': title='CÔNG TẮC\nCHỐNG NGHIÊNG'
        else: xx,yy,anchor=x+w/2,y-12,'middle'
        if cid=='turn-switch':title='CÔNG TẮC\nXI NHAN'
        lines=title.splitlines()
        # Multi-line labels end at the chosen baseline above the symbol.
        for i,s in enumerate(lines): caption(c,s,xx,yy+16*(i-(len(lines)-1)/2 if anchor!='middle' or yy>y else i-len(lines)+1),14,anchor)
    if d['circuitTitle']=='Mạch đèn đêm':
        c=comp(d,'fuse-turn');c['captions']=[text('CẦU CHÌ (10A) TURN...',928,360,13)]
    if d['circuitTitle']=='Mạch cấp nguồn':
        c=comp(d,'fuse-turn-horn');c['captions']=[text('CẦU CHÌ (10A) TURN,HORN...',1170,303,12)]
    if d['circuitTitle']=='Mạch đánh lửa':
        comp(d,'ckp')['captions']=[text('CẢM BIẾN CKP',807,501,14)]
    if overview: overview_captions(d)

def overview_captions(d):
    specs={
        'fuse-main':('CẦU CHÌ (20A) MAIN',191,666), 'fuse-fi':('CẦU CHÌ (10A) FI',263,670),
        'fuse-horn':('CẦU CHÌ (10A)\nHORN,TURN...',181,216), 'main-relay':('RƠ LE CHÍNH',187,349),
        'ignition-switch':('CÔNG TẮC MÁY',253,498),'capacitor':('TỤ ĐIỆN',368,484),
        'regulator':('TIẾT CHẾ/\nCHỈNH LƯU',383,669),'acg':('MÁY PHÁT',600,830),
        'starter-relay':('RƠ LE\nKHỞI\nĐỘNG',824,107), 'starter-motor':('MÔ TƠ\nKHỞI\nĐỘNG',987,110),
        'idle-valve':('VAN TỪ\nCẦM CHỪNG NHANH',610,290),'fuel-pump':('BƠM XĂNG',708,344),
        'injector':('KIM PHUN',866,268),'ignition-coil':('MÔ-BIN\nSƯỜN',990,286),
        'spark-plug':('BUGI',1066,310),'mil':('MIL',1210,280),'temperature-lamp':('ĐÈN CẢNH BÁO NHIỆT ĐỘ',1280,280),
        'front-brake-switch':('CÔNG TẮC PHANH TRƯỚC',1347,251),'rear-brake-switch':('CÔNG TẮC PHANH SAU',1450,250),
        'starter-switch':('CÔNG TẮC KHỞI ĐỘNG',1387,726),'ckp':('CẢM BIẾN CKP',600,733),
        'tp':('CẢM\nBIẾN\nTP',688,834),'iat':('CẢM\nBIẾN\nIAT',791,837),
        'ect':('CẢM BIẾN ECT',857,846),'oxygen':('CẢM\nBIẾN\nÔXY',975,833),
        'side-stand-switch':('CÔNG TẮC CHỐNG NGHIÊNG',1030,750),'dlc':('DLC',1230,724),'scs-tool':('ĐẦU NỐI SCS',1222,828)}
    for cid,(s,x,y) in specs.items():
        if cid=='regulator':continue
        c=comp(d,cid); ls=s.splitlines()
        for i,t in enumerate(ls): caption(c,t,x+(i-(len(ls)-1)/2)*14,y,12,'middle',-90)
    for t in comp(d,'idle-valve')['captions']:t['size']=10;t['y']=280
    d.setdefault('extraDrawing',[]).append(rect(1475,433,116,397,'white',width=2))
    note(d,'Ghi chú',1478,779,17,'middle',-90)
    for s,x in [('DTC / MÃ MIL',1501),('ĐỘNG CƠ KHÔNG KHỞI ĐỘNG NẾU CÓ HƯ HỎNG',1534),('CẮM ĐẦU CỰC NÀY ĐỂ ĐỌC DTC / MÃ MIL',1570)]: note(d,s,x,623,12,'middle',-90)
    note(d,'ĐIỆN TRỞ:',855,423,10,'middle',-90);note(d,'20°C = 9 – 12 Ω',871,423,10,'middle',-90)
    for s,x in [('ĐIỆN TRỞ (Ω)',868),('40°C: 1,0 – 1,3 (kΩ)',882),('100°C: 0,1 – 0,2 (kΩ)',896)]: note(d,s,x,848,9,'middle',-90)
    for label,x,y in [('(12)',846,256),('(33)',842,494),('(8)',648,831),('(9)',752,831),('(7)',836,831),('(21)',934,831)]:
        d['extraDrawing'].append(rect(x-8,y+15,16,20,'#ffff26'))
        note(d,label,x+2,y,12,'middle',-90)
        # Miniature engine/MIL outline used by the original legend.
        d['extraDrawing'] += [line([[x-4,y+20],[x-1,y+20],[x-1,y+18],[x+3,y+18],[x+3,y+20],[x+5,y+20],[x+5,y+29],[x+3,y+29],[x+3,y+32],[x-4,y+32],[x-4,y+20]],closed=True,fill='white',width=1),line([[x-6,y+22],[x-6,y+29]],width=1)]
    # Crossed-circle symbols and SCS jumper in the legend, also present by CKP/injector.
    for x,y in [(1499,799),(1530,775),(842,245),(592,659)]:
        d['extraDrawing'] += [ellipse(x,y,8),line([[x-6,y-6],[x+6,y+6]]),line([[x-6,y+6],[x+6,y-6]])]
    # The first legend is the MIL icon, the third is the SCS connector silhouette.
    d['extraDrawing'] += [rect(1490,788,18,23,'#ffff26'),line([[1494,793],[1499,793],[1499,791],[1504,793],[1504,805],[1494,805],[1494,793]],closed=True,fill='white',width=1),line([[1568,791],[1568,782],[1565,782],[1565,777],[1568,777],[1568,762],[1577,762],[1577,777],[1581,777],[1581,782],[1577,782],[1577,791],[1568,791]],'#df163b',1.5)]

def ground_graphics(c,e):
    x,y,w,h=c['x'],c['y'],c['width'],c['height']; t=c['terminals'][0]; tx,ty=t['x'],t['y']
    green=c.get('groundColor',PALETTE['G']); width=max(2,min(7,h/4))
    if abs(tx-x)<8 and abs(ty-(y+h/2))<8 and h>w:
        for k,span in enumerate([h*.5,h*.32,h*.15]): e.append(line([[tx+k*8,ty-span],[tx+k*8,ty+span]],green,4))
    else:
        for k,span in enumerate([w*.5,w*.32,w*.15]): e.append(line([[tx-span,ty+k*h*.33],[tx+span,ty+k*h*.33]],green,width))

def box_pins(c,e,overview=False):
    x,y,w,h=c['x'],c['y'],c['width'],c['height']; locator=c['id']=='locator'
    if locator:
        e += [rect(x+14,y,w-28,20,GREY),rect(x,y+24,w,h-24,'#bdaa50')]
    else: e.append(rect(x,y,w,h,'#fcff21' if w>200 else '#fbfc63'))
    for t in c['terminals']:
        if not t.get('label') or not (w>200 or locator): continue
        if overview:
            upper=t['y']==y; cy=y+36 if upper else y+h-36
            e.append(rect(t['x']-10,cy-36,20,72,'white',width=1))
            code=t['label'].split(' ',1)
            e.append(text(code[0],t['x']+4,t['y']+(8 if upper else -7),10,'middle',-90))
            if len(code)>1:
                if code[1]=='O₂':
                    e += [text('O',t['x']+4,cy-13,11,'middle',-90),text('2',t['x']+7,cy-21,8,'middle',-90)]
                else:e.append(text(code[1],t['x']+4,cy+(17 if upper else -13),11,'middle',-90))
        else:
            pin_y=y+24 if locator else y
            e.append(rect(t['x']-11,pin_y,22,29 if locator else 22,'white',width=1))
            e.append(text(t['label'],t['x'],pin_y+20 if locator else pin_y+17,14))
    if overview:
        e.append(rect(833,460,47,76,'#efffcd',stroke='none'))
        e.append(text('ECM',872,499,22,'middle',-90)); return
    if locator:
        e.append(rect(x+98,y+75,227,98,'white',stroke='none'))
        e += [text('HỘP',x+w/2,y+112,31),text('ĐỊNH VỊ XE',x+w/2,y+154,36)]
    else:
        size=50 if w==280 else (26 if w>200 else 25)
        if w>200: e.append(rect(x+w*.22,y+h*.36,w*.57,h*.44,'white',stroke='none'))
        e.append(text('ECM',x+w*.5,y+h*.68,size))

def pinout(c,e):
    x,y,w,h=c['x'],c['y'],c['width'],c['height']; large=w<h
    e += [rect(x,y,w,h,'white',width=2),rect(x+5,y+5,w-10,h-10,'white',width=2),rect(x+11,y+11,w-22,h-22,'white')]
    cols,rows=(3,11) if large else (5,2)
    for row in range(rows):
        for col in range(cols):
            xx=x+16+col*(w-32)/cols; yy=y+16+row*(h-32)/rows; cw=(w-32)/cols;ch=(h-32)/rows
            e.append(rect(xx,yy,cw,ch,'white',width=1))
            val=(11-row)+col*11 if large else 1+row*5+col
            e.append(text(str(val),xx+cw/2+(3 if large else 0),yy+ch/2+(0 if large else 6),9 if large else 20,'middle',-90 if large else 0))
    if large:
        for i,s in enumerate(c['label'].splitlines()):e.append(text(s,x+w+19+i*16,y+h/2,14,'middle',-90))
    else: e.append(text(c['label'],x+w/2,y+h+33,18))

def component_graphics(d,c):
    e=[]; x,y,w,h=c['x'],c['y'],c['width'],c['height']; cid=c['id']; typ=c['type']; overview='PGM-FI' in d['circuitTitle']; sym=c.get('symbol')
    if typ=='junction':
        # Only the explicitly drawn dots in the source, not every logical graph split.
        if w>=12:
            colors=[v.get('primaryColor') for v in d['wires'] if v['to']['componentId']==cid or v['from']['componentId']==cid]
            color=colors[0] if colors else '#333333'; t=c['terminals'][0]; e.append(ellipse(t['x'],t['y'],w/2,fill=color,stroke='none'))
    elif typ=='ground': ground_graphics(c,e)
    elif typ=='battery': use(e,'battery',x,y,w,h,100,83, -90 if overview else 0)
    elif typ=='fuse': use(e,'fuse',x,y,w,h,100,46,90 if h>w else 0)
    elif typ=='relay':
        use(e,'relay-start' if cid=='relay-starter' else 'relay',x,y,w,h,100,145,-90 if (overview and cid=='main-relay') or cid=='relay-starter' else 0)
    elif typ=='ecm' or cid=='locator': box_pins(c,e,overview)
    elif sym=='pinout': pinout(c,e)
    elif c.get('combLabels'):
        labs=c['combLabels'];e.append(line([[x,labs[0][1]],[x,labs[-1][1]]],width=2))
        for label,yy in labs: e += [line([[x,yy],[x+w,yy]],width=2),text(label,x+w+6,yy+4,12,'start')]
    elif c.get('arrow'):
        e.append(line([[x-17,y+10],[x,y+18],[x-17,y+26]],closed=True,fill=PALETTE['Y'],stroke=PALETTE['Y']))
        e.append(text('CÔNG TẮC ĐÈN ĐÊM',x+4,y+23,13,'start'))
    elif sym=='stand-switch':
        e += [rect(x,y,w,h,PALE),line([[1389,669],[1389,706]]),line([[1432,669],[1432,688]]),line([[1389,706],[1441,720]]),ellipse(1389,706,6),ellipse(1432,688,6),ellipse(1432,725,6)]
    elif typ=='switch' and len(c['terminals'])==4:
        e.append(rect(x,y,w,h,PALE));use(e,'switch-contact',x,y,w,h/2,100,56);use(e,'switch-contact',x,y+h/2,w,h/2,100,56)
    elif typ=='switch':
        push=cid in ('horn-switch','switch-start','starter-switch')
        use(e,'push-switch' if push else 'switch',x,y,w,h,100,64 if push else 56,(-90 if overview else 90) if h>w else 0)
    elif typ=='selectorSwitch': use(e,'dimmer' if cid=='dimmer' else 'selector',x,y,w,h,100,88)
    elif sym in ('led-panel','led-single','speaker','headlamp'):
        nw,nh={'led-panel':(48,100),'led-single':(100,90),'speaker':(100,100),'headlamp':(100,100)}[sym]
        use(e,sym,x,y,w,h,nw,nh)
    elif typ=='lamp':
        if overview:
            e.append(ellipse(x+w/2,y+h/2,w/2,h/2))
            if cid=='temperature-lamp':
                e += [line([[x+w*.2,y+6],[x+w*.8,y+6],[x+w*.5,y+h*.7]],closed=True,fill='#222222'),line([[x+w*.2,y+h*.75],[x+w*.8,y+h*.75]])]
            else: e.append(coil(x+w*.5-1,y+8,2,h*.2,3))
        else: use(e,'bulb',x,y,w,h)
    elif typ=='horn':use(e,'horn',x,y,w,h)
    elif typ=='gauge':use(e,'gauge',x,y,w,h,100,127)
    elif cid=='fuel-sender':use(e,'sender',x,y,w,h,100,66)
    elif typ=='flasher':use(e,'flasher',x,y,w,h,100,60)
    elif typ=='diode':use(e,'diode',x,y,w,h,100,80)
    elif 'capacitor' in cid:use(e,'capacitor',x,y,w,h,56,100,180 if overview else 0)
    elif cid in ('load-resistor','resistor'):use(e,'resistor',x,y,w,h,38,100)
    elif cid=='ckp-rotor':use(e,'rotor',x,y,w,h)
    elif cid=='ckp':use(e,'ckp',x,y,w,h,48,100,-90 if overview else 0)
    elif typ=='acg':use(e,'acg',x,y,w,h,100,100,-90 if overview else 0)
    elif cid=='regulator':
        e.append(rect(x,y,w,h,GREY))
        if overview:
            e += [text('TIẾT CHẾ/',x+w*.46,y+h*.5,12,'middle',-90),text('CHỈNH LƯU',x+w*.63,y+h*.5,12,'middle',-90)]
        else:e += [text('TIẾT CHẾ/',x+w/2,y+h*.47,13),text('CHỈNH LƯU',x+w/2,y+h*.65,13)]
    elif typ=='ignitionCoil':use(e,'ignition-coil',x,y,w,h,68,100,-90 if overview else 0)
    elif typ=='sparkPlug':use(e,'spark-plug',x,y,w,h,66,113,-90 if overview else 0)
    elif typ=='motor':
        use(e,'pump' if overview else 'motor',x,y,w,h,100,100,90 if overview else 0)
        if not overview:e += [line([[305,693],[317,705]],width=2),line([[438,693],[427,705]],width=2),line([[372,798],[372,804]],width=2)]
    elif typ=='pump':use(e,'pump',x,y,w,h)
    elif cid in ('tp','iat','ect'):use(e,'tp' if cid=='tp' else 'thermistor',x,y,w,h,100,65)
    elif cid=='oxygen':use(e,'oxygen',x,y,w,h,44,100)
    elif typ=='valve':use(e,'valve',x,y,w,h,100,60)
    elif typ=='injector':use(e,'injector',x,y,w,h,88,60)
    elif cid=='dlc':e.append(rect(x,y,w,h,'white','#db1748',2))
    elif cid=='scs-tool':e += [rect(x,y+10,w,18,'white','#db1748',2),line([[x+70,y+28],[x+70,y+64],[x+75,y+73],[x+86,y+78],[x+96,y+73],[x+100,y+64],[x+100,y+28]],'#db1748',2)]
    else: raise ValueError('Unimplemented symbol '+cid)
    for item in e:item['owner']=cid;item['role']='symbol'
    e.extend(dict(t,owner=cid,role='component-label') for t in c.get('captions',[]))
    return e

def stripe_segments(pts,dash=11,gap=17):
    distance=0; result=[]
    for a,b in zip(pts,pts[1:]):
        dx=b[0]-a[0];dy=b[1]-a[1];length=math.hypot(dx,dy)
        if not length:continue
        pos=0
        while pos<length-1e-6:
            phase=distance%(dash+gap); on=phase<dash
            n=min(length-pos,(dash-phase if on else dash+gap-phase))
            if n<1e-6: n=min(length-pos,1e-5)
            if on:result.append([[a[0]+dx*pos/length,a[1]+dy*pos/length],[a[0]+dx*(pos+n)/length,a[1]+dy*(pos+n)/length]])
            pos+=n;distance+=n
    return result

def wire_graphics(w,overview=False):
    pts=[[p['x'],p['y']] for p in w['points']]; color=w['primaryColor']; sw=5 if overview else 8
    if not w.get('code'):sw=2
    e=[]
    if color=='#ffffff': e.append(line(pts,'#8a8a8a',sw+1.5))
    e.append(line(pts,color,sw))
    if w.get('stripeColor'):
        for segment in stripe_segments(pts,6 if overview else 11,15 if overview else 18): e.append(line(segment,w['stripeColor'],sw*.65))
    for item in e:item['owner']=w['id'];item['role']='wire'
    return e

def auto_wire_labels(d):
    # Initial placement is deterministic; exceptions mirror where labels sit in the source.
    overview='PGM-FI' in d['circuitTitle']
    for w in d['wires']:
        if not w.get('code'): continue
        pts=w['points']; segs=[]
        for a,b in zip(pts,pts[1:]):
            dx=b['x']-a['x'];dy=b['y']-a['y'];length=math.hypot(dx,dy)
            if length<24:continue
            segs.append((length,a,b))
        if not segs:continue
        _,a,b=max(segs,key=lambda z:z[0])
        x=(a['x']+b['x'])/2;y=(a['y']+b['y'])/2
        if abs(a['y']-b['y'])<2: y-=9;rotation=0
        elif overview:x-=8;rotation=-90
        else:x+=12;rotation=0
        w['labels']=[text(w['code'],x,y,11 if overview else 14,rotate=rotation)]
    # Junction splits should not introduce duplicate markings absent from the source.
    suppress={
        'Mạch cấp nguồn':['battery-positive-wire','positive-trunk','main-output','ignition-feed','ignition-output','relay-output','turn-horn-feed'],
        'Mạch còi':['battery-feed'], 'Mạch xi nhan':['battery-power'], 'Mạch đèn phanh':['battery-positive','brake-lamp-feed'],
        'Mạch báo xăng':['battery-power','gauge-ground-branch','sender-ground-branch'],
        'Mạch điện xác định vị trí xe':['w-battery-r','w-r-bus','w-j-seat'],
        'Mạch khởi động':['w-battery-red','w-red-bus','w-black-bus','w-brake-front-in','w-brake-rear-in'],
        'Mạch đèn đêm':['battery-feed','dimmer-high','brown-trunk'],
        'Mạch đánh lửa':['w-ecm-2-ground','w-ecm-10-ground','w-green-ground']
    }.get(d['circuitTitle'],[])
    for w in d['wires']:
        if w['id'] in suppress:w['labels']=[]
    overrides={
        'Mạch còi':{'battery-ground':[(195,411)],'feed-main':[(350,411)],'feed-fi':[(384,485)],'relay-ecm':[(1038,484)],'horn-ground':[(1565,410)]},
        'Mạch xi nhan':{'battery-ground':[(195,438)],'power-main':[(334,438)],'power-fi':[(363,511)],'relay-ecm':[(829,511)],'switch-left':[(1412,388)],'left-ground':[(1470,388)],'switch-right':[(1410,512)],'right-ground':[(1470,603)]},
        'Mạch đèn phanh':{'battery-negative':[(196,383)],'main-fuse-feed':[(340,383)],'fi-fuse-feed':[(369,460)],'front-brake-feed':[(1125,316)],'rear-brake-feed':[(1125,458)],'front-brake-output':[(1230,400)],'rear-brake-output':[],'brake-output-tap':[(1360,382)],'relay-ecm':[(849,459)],'resistor-feed':[(1373,463)],'lamp-ground-wire':[(1459,483)],'resistor-ground-wire':[]},
        'Mạch báo xăng':{'battery-ground':[(184,278)],'power-main-fuse':[(341,278)],'power-fi-fuse':[(377,352)],'relay-ecm':[(1045,352)],'gauge-sender':[(1320,444)],'fuel-branch-ground':[(1393,432)]},
        'Mạch đánh lửa':{'w-battery-ground':[(195,233)],'w-battery-fuse':[(296,233)],'w-power-capacitor':[(477,279)],'w-capacitor-ground':[(508,384)],'w-ignition-ecm':[(978,465)],'w-ignition-coil':[(1276,233)],'w-ecm-coil':[(1270,279),(1014,505)],'w-ecm-side-stand':[(1250,319),(1094,507)],'w-ecm-green':[(1242,359),(1128,526)],'w-green-side-stand':[(1366,359)],'w-ecm-2-ground':[(1224,398)],'w-ecm-10-ground':[(1226,453)],'w-green-ground':[(1352,510)],'w-ckp-12':[(898,531)]},
        'Mạch điện xác định vị trí xe':{'w-r-main':[(323,132)],'w-r-fi':[(323,209)],'w-r-answer':[(324,292)],'w-battery-ground':[(190,293)],'w-relay-ecm':[(887,209)],'w-turn-locator':[(1210,133)],'w-answer-j':[(519,293)],'w-j-key':[(515,537)],'w-j-locator':[(612,417)],'w-seat-locator':[(610,447)],'w-key-locator':[(610,568)],'w-locator-ground':[(721,616)],'w-locator-left':[(1297,396)],'w-locator-right':[(1297,496)],'w-left-ground':[(1356,447)],'w-right-ground':[(1354,548)],'w-locator-horn-bu':[(1297,625)],'w-locator-horn-gp':[(1297,676)]},
        'Mạch khởi động':{'w-main-in':[(367,125)],'w-fi-in':[(368,222)],'w-starter-feed':[(345,284)],'w-main-coil-feed':[(915,179)],'w-ecm-1':[(893,579)],'w-ecm-7':[(999,278),(952,579)],'w-brake-feed':[(1350,125),(1412,282)],'w-brake-rear-out':[(1410,398)],'w-brake-front-out':[],'w-brake-start':[(1431,447)],'w-start-right':[(1325,488)],'w-ecm-29':[(1063,488),(995,581)],'w-resistor-in':[(1399,539)],'w-battery-ground':[(196,222)],'w-battery-motor':[(202,291),(224,635)],'w-motor-lug-ground':[(536,697)],'w-motor-power':[(350,647)]},
        'Mạch cấp nguồn':{'battery-ground-wire':[(180,403)],'answer-back-feed':[(301,247)],'main-feed':[(301,328)],'fi-feed':[(301,404)],'regulator-dc':[(509,469)],'capacitor-feed-upper':[(697,442)],'capacitor-feed-lower':[(696,492)],'capacitor-ground-wire':[(685,596)],'relay-coil-feed':[(856,403)],'relay-ecm':[(1076,451)],'headlight-feed':[(1080,240)],'relay-output':[(1017,328)],'engine-bl-bus':[(1082,591)],'turn-horn-output':[(1245,328)],'acg-left-wire':[(399,495)],'acg-top-wire':[(422,537)],'acg-right-wire':[(448,579)]},
        'Mạch đèn đêm':{'battery-ground':[(195,373)],'main-feed':[(332,373)],'fi-feed':[(366,447)],'relay-ecm':[(815,446)],'j-head':[(864,303)],'j-turn':[],'relay-j':[],'head-switch':[(1004,303),(1048,330)],'high-indicator-feed':[(1390,186)],'high-ground':[(1406,232)],'head-ground':[(1394,396)],'position-ground':[(1401,517)],'license-ground':[(1401,640)],'tail-ground':[(1433,761)],'switch-brown':[(1170,377)]}
    }.get(d['circuitTitle'],{})
    for wid,locs in overrides.items():
        w=wire(d,wid); w['labels']=[text(w['code'],x,y,14) for x,y in locs]
    if d['circuitTitle']=='Mạch khởi động':
        wire(d,'w-brake-feed')['labels']=[text('Bl/Br',1350,125,14)]
        wire(d,'w-brake-rear-in')['labels']=[text('Bl',1412,282,14)]
    if d['circuitTitle']=='Mạch đánh lửa':
        wire(d,'w-ecm-coil')['labels'][1]['size']=12
    if overview:
        locs={
            'w-main-regulator':[(348,604,-90)],'w-fi-ignition':[(278,609,-90)],
            'w-starter-motor':[(987,157,-90)],'w-coil-power':[(908,266,-90)],
            'w-mil-feed':[(1218,172,-90),(213,109,-90)],'w-temperature-feed':[(1290,174,-90)],
            'w-front-brake-feed':[(1364,151,-90)],'w-rear-brake-feed':[(1410,151,-90)],
            'w-iat-signal':[(738,721,-90)],'w-iat-return':[(782,721,-90)],
            'w-dlc-power':[(1110,671,-90)],'w-lg-ground':[],
            'w-pg2-ground':[(1217,635,-90)],'w-pg1-ground':[(1243,631,-90)],
            'w-battery-starter':[(149,478,-90)],'w-starter-control':[(1154,326,-90)],
            'w-idle-power':[(550,285,-90)],'w-ignition-power':[(350,342,-90)],
            'w-power-igp':[(646,345,-90)],'w-power-starter-relay':[],
            'w-stand-ground':[(1041,820,-90)],'w-rear-brake-start':[(1411,497,-90)],
            'w-front-brake-start':[(1368,307,-90)]}
        for wid,positions in locs.items():
            w=wire(d,wid);w['labels']=[text(w['code'],x,y,11,rotate=r) for x,y,r in positions]

def build_drawing(d):
    overview='PGM-FI' in d['circuitTitle']; elems=[]
    for w in d['wires']:
        cs=w.get('code','').split('/');w['primaryColor']=PALETTE.get(cs[0], '#343434');w.pop('stripeColor',None)
        if len(cs)>1:w['stripeColor']=PALETTE[cs[1]]
    for c in d['components']:
        if c['type']=='ground' and (c['id'] in ('ground-ecm','ecm-ground','ground-resistor','ground-motor')):c['groundColor']='#343434'
    set_captions(d);auto_wire_labels(d)
    for w in d['wires']:elems.extend(wire_graphics(w,overview))
    for c in d['components']:elems.extend(component_graphics(d,c))
    # DLC power goes across the ECM body in the original drawing.
    if overview:elems.extend(wire_graphics(wire(d,'w-dlc-power'),True))
    for w in d['wires']:
        elems.extend(dict(t,owner=w['id'],role='wire-label') for t in w.get('labels',[]))
    elems.extend(d.pop('extraDrawing',[]))
    used={e['symbol'] for e in elems if e['kind']=='use'}
    d['drawing']=dict(version=1,background='#ffffff',fontFamily='Arial',symbols={s:SYMBOLS[s] for s in sorted(used)},elements=elems)
    return d

def crop_coordinates(d):
    # Uniform source crop, retaining all diagram annotations and removing app chrome.
    dx,dy=127,64
    for c in d['components']:
        c['x']-=dx;c['y']-=dy
        for t in c['terminals']:t['x']-=dx;t['y']-=dy
        for t in c.get('captions',[]):t['x']-=dx;t['y']-=dy
        if 'combLabels' in c:c['combLabels']=[[s,y-dy] for s,y in c['combLabels']]
    for w in d['wires']:
        for p in w['points']:p['x']-=dx;p['y']-=dy
        for t in w.get('labels',[]):t['x']-=dx;t['y']-=dy
    # Isolate each primitive: an outline and its colored stroke may share point objects.
    d['drawing']['elements']=[copy.deepcopy(e) for e in d['drawing']['elements']]
    for e in d['drawing']['elements']:
        if e['kind']=='use':e['matrix'][4]-=dx;e['matrix'][5]-=dy
        elif e['kind']=='text':e['x']-=dx;e['y']-=dy
        else:
            for p in e['points']:p[0]-=dx;p[1]-=dy
    d['canvas']=dict(width=1499,height=844,background='#ffffff')
    d['sourceCrop']=dict(x=dx,y=dy,width=1499,height=844)

def main():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    original_by_id = {source['id']: source for source in (read(p.name) for p in INPUT.glob('*.json'))}
    docs=[patch_power(),patch_existing('Mạch còi.json'),patch_existing('Mạch xi nhan.json'),patch_existing('Mạch đèn phanh.json'),patch_existing('thang-fuel-indicator.schema.json'),make_night(),patch_existing('thang-ignition.schema.json'),patch_existing('thang-starting.schema.json'),patch_existing('Mạch xác định vị trí xe.json'),patch_existing('Sơ đồ nguyên lý hệ thống.json')]
    for i,d in enumerate(docs,1):
        # The destination app validates vehicleTitle as part of project identity.
        # Keep these fields exactly as exported, even when the title is a nickname.
        for key in ('id', 'vehicleId', 'vehicleTitle', 'schemaVersion'):
            d[key] = original_by_id[d['id']][key]
        d['reviewStatus']='draft'
        d['reviewMetadata']={'vectorPreviewGenerated':True,'targetAppVerified':False,'source':'supplied screenshots','electricalSimulationValidated':False}
        d['colorReference']={'method':'Median RGB of a 3x3 screenshot patch; white uses #ffffff. Representative visible colors, not a claim to recover pre-compositing colors.', 'palette':PALETTE,'samples':{code:{'sourceImage':f'Screenshot from 2026-09-30 {s}.png','x':x,'y':y} for code,(s,x,y) in PALETTE_SAMPLES.items()}}
        d['renderContract']='Use drawing.version=1 to reproduce the reviewed vector preview. Legacy components/wires alone do not describe the detailed glyphs.'
        d['reviewChanges'].append('Thêm lớp vector tự chứa: hình linh kiện, nhãn và số chân; bỏ nền app khỏi bản vẽ.')
        build_drawing(d);crop_coordinates(d)
        from diagram_text import enrich_diagram_text
        d=enrich_diagram_text(d)
        basename=f'{i:02d}. {d["circuitTitle"]}'
        (OUTPUT/(basename+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
        render(d,OUTPUT/'preview'/basename)
        print('Rendered',basename)
    (OUTPUT/'symbol-library.json').write_text(json.dumps(dict(version=1,symbols=SYMBOLS),ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':main()
