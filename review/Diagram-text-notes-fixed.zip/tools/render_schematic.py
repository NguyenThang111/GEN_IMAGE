"""Render the self-contained vector extension in an AirBlade JSON to SVG / PNG.

No source image is used by this renderer. Pillow is needed only for PNG / metrics.
Coordinates and text positions are explicit; there is no automatic graph layout.
"""
import argparse
import html
import json
import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
FONT = Path('C:/Windows/Fonts/arial.ttf')
BOLD = Path('C:/Windows/Fonts/arialbd.ttf')

def font(size, bold=True):
    return ImageFont.truetype(str(BOLD if bold else FONT), max(1, round(size)))

def text_box(e):
    f = font(e.get('size', 14), e.get('bold', True))
    b = f.getbbox(e['text'], anchor='ls')
    width = f.getlength(e['text'])
    dx = {'start': 0, 'middle': -width / 2, 'end': -width}[e.get('anchor', 'middle')]
    x, y = e['x'], e['y']
    angle = math.radians(e.get('rotate', 0))
    pts = [(x+(dx+u)*math.cos(angle)-v*math.sin(angle), y+(dx+u)*math.sin(angle)+v*math.cos(angle)) for u,v in [(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3])]]
    return (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))

def flatten(d):
    result = []
    symbols = d['drawing'].get('symbols', {})
    def emit(e, m=(1,0,0,1,0,0), owner=None):
        a,b,c,f,tx,ty = m
        def xy(x,y): return [round(a*x+c*y+tx,3), round(b*x+f*y+ty,3)]
        if e['kind'] == 'use':
            n = e['matrix']; A,B,C,D,X,Y=n
            nm=(a*A+c*B,b*A+f*B,a*C+c*D,b*C+f*D,a*X+c*Y+tx,b*X+f*Y+ty)
            for child in symbols[e['symbol']]: emit(child,nm,e.get('owner',owner))
            return
        r = dict(e)
        if owner: r['owner'] = owner
        if e['kind'] == 'text':
            r['x'],r['y']=xy(e['x'],e['y'])
            r['size']=e.get('size',14)*math.sqrt(abs(a*f-b*c))
            r['rotate']=e.get('rotate',0)+math.degrees(math.atan2(b,a))
        else:
            r['points']=[xy(*p) for p in e['points']]
            r['width']=e.get('width',1.5)*math.sqrt(abs(a*f-b*c))
        result.append(r)
    for e in d['drawing']['elements']: emit(e)
    return result

def svg_text(e):
    return '<text x="{x}" y="{y}" font-family="Arial, sans-serif" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" fill="{fill}" transform="rotate({rotate} {x} {y})">{text}</text>'.format(x=e['x'],y=e['y'],size=e.get('size',14),weight=700 if e.get('bold',True) else 400,anchor=e.get('anchor','middle'),fill=e.get('fill','#343434'),rotate=e.get('rotate',0),text=html.escape(e['text']))

def render(d, out, scale=2):
    out=Path(out); out.parent.mkdir(parents=True,exist_ok=True)
    w,h=d['canvas']['width'],d['canvas']['height']
    items=flatten(d)
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">', '<rect width="100%" height="100%" fill="white"/>']
    im=Image.new('RGB',(round(w*scale),round(h*scale)),'white'); draw=ImageDraw.Draw(im)
    for e in items:
        if e['kind']=='text':
            svg.append(svg_text(e))
            f=font(e.get('size',14)*scale,e.get('bold',True))
            txt=e['text']; anc={'start':'ls','middle':'ms','end':'rs'}[e.get('anchor','middle')]
            if abs(e.get('rotate',0))<0.01:
                draw.text((e['x']*scale,e['y']*scale),txt,font=f,fill=e.get('fill','#343434'),anchor=anc)
            else:
                # Square centered on the text anchor, so rotation keeps that anchor fixed.
                extent=round(f.getlength(txt)+f.size*4); extent=max(extent,100)
                layer=Image.new('RGBA',(extent*2,extent*2))
                ImageDraw.Draw(layer).text((extent,extent),txt,font=f,fill=e.get('fill','#343434'),anchor=anc)
                layer=layer.rotate(-e.get('rotate',0),resample=Image.Resampling.BICUBIC)
                im.paste(layer,(round(e['x']*scale-extent),round(e['y']*scale-extent)),layer)
        else:
            pts=e['points']; closed=e.get('closed',False); fill=e.get('fill','none'); stroke=e.get('stroke','#555555'); width=e.get('width',1.5)
            svg.append('<{tag} points="{pts}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="{cap}"/>'.format(tag='polygon' if closed else 'polyline',pts=' '.join(f'{p[0]},{p[1]}' for p in pts),fill=fill,stroke=stroke,width=width,cap=e.get('cap','butt')))
            pixels=[(x*scale,y*scale) for x,y in pts]
            if closed and fill!='none': draw.polygon(pixels,fill=fill)
            if stroke!='none' and width>0:
                if closed: pixels.append(pixels[0])
                draw.line(pixels,fill=stroke,width=max(1,round(width*scale)),joint='curve')
    svg.append('</svg>')
    Path(str(out)+'.svg').write_text('\n'.join(svg),encoding='utf-8')
    im.save(Path(str(out)+'.png'))
    return items

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('json',type=Path); p.add_argument('--out',type=Path); p.add_argument('--scale',type=float,default=2)
    a=p.parse_args(); data=json.loads(a.json.read_text(encoding='utf-8-sig'))
    render(data,a.out or a.json.with_suffix(''),a.scale)
