"""Reusable hand-drawn vector symbols. Coordinates normalized to 100 x 100.

These are vector primitives, not bitmap crops from the reference screenshots.
"""
import math

INK='#555555'; PALE='#fbfca7'; GREY='#dedfe0'; WHITE='#ffffff'

def line(points,stroke=INK,width=1.5,**kw):
    return dict(kind='path',points=points,stroke=stroke,width=width,**kw)
def rect(x,y,w,h,fill=WHITE,stroke=INK,width=1.5):
    return line([[x,y],[x+w,y],[x+w,y+h],[x,y+h]],stroke,width,closed=True,fill=fill)
def ellipse(x,y,rx,ry=None,fill=WHITE,stroke=INK,width=1.5):
    if ry is None: ry=rx
    return line([[x+rx*math.cos(t*math.pi/32),y+ry*math.sin(t*math.pi/32)] for t in range(64)],stroke,width,closed=True,fill=fill)
def text(s,x,y,size=14,anchor='middle',rotate=0,bold=True,**kw):
    return dict(kind='text',text=s,x=x,y=y,size=size,anchor=anchor,rotate=rotate,bold=bold,fill='#343434',**kw)
def coil(x,y,w,h,loops=4):
    return line([[x+w*t/240+w/(loops*2.5)*math.sin(t/240*loops*2*math.pi),y+h*(math.cos(t/240*loops*2*math.pi)-1)/2] for t in range(241)])
def zigzag(x,y,w,h,n=5):
    return line([[x,y]]+[[x+(-1 if i%2==0 else 1)*w/2,y+h*(i+1)/(n*2+1)] for i in range(n*2)]+[[x,y+h]])

def library():
    s={}
    s['fuse']=[rect(0,0,100,46),line([[0,24],[17,24]]),line([[83,24],[100,24]]),ellipse(20,24,8),ellipse(80,24,8),line([[28+44*t/60,24-10*math.sin(t/60*math.pi)**2] for t in range(61)])]
    s['switch']=[rect(0,0,100,56,PALE),line([[0,34],[20,34]]),line([[80,34],[100,34]]),line([[24,32],[80,10]],width=2),ellipse(25,34,8),ellipse(77,34,8)]
    s['push-switch']=[rect(0,0,100,64,PALE),line([[0,47],[25,47]]),line([[75,47],[100,47]]),line([[25,35],[75,35]],'#343434',9),line([[50,35],[50,-5]],'#343434',12),ellipse(28,47,6),ellipse(72,47,6)]
    s['selector']=[rect(0,0,100,88,PALE),line([[0,44],[30,44]]),line([[70,23],[100,23]]),line([[70,67],[100,67]]),line([[30,44],[78,44]]),line([[26,42],[14,22]]),ellipse(32,44,7),ellipse(69,23,7),ellipse(69,67,7)]
    s['relay']=[rect(0,0,100,145,PALE),line([[20,12],[80,12]]),line([[0,27],[22,27]]),line([[77,27],[100,27]]),ellipse(23,27,8),ellipse(76,27,8),line([[0,122],[15,122]]),line([[86,122],[100,122]]),coil(15,122,71,10,4)]
    s['battery']=[rect(0,13,100,70,GREY),rect(12,2,16,11),rect(72,2,16,11),ellipse(20,29,10),ellipse(80,29,10),line([[12,29],[28,29]],'#5cac83',1),line([[72,29],[88,29]],'#d16473',1),line([[80,21],[80,37]],'#d16473',1),text('ẮC QUY',50,68,14)]
    s['bulb']=[ellipse(71,50,29,46),rect(0,23,45,54),line([[0,38],[45,38],[68,18],[74,27]]),line([[0,62],[45,62],[69,84],[75,74]]),line([[45,23],[45,77]]),coil(71,28,0.1,0.1)]
    # Filament wound vertically between the bulb's two leads.
    s['bulb'].pop(); s['bulb'] += [line([[72+8*(math.cos(i/180*6*math.pi)-1)/2,27+i*46/180-5*math.sin(i/180*6*math.pi)] for i in range(181)])]
    s['led-panel']=[rect(0,0,48,100),rect(4,5,4,90),line([[8,20],[26,20],[26,80],[8,80]])]
    for y in [20,49,78]:
        s['led-panel'] += [line([[8,y],[25,y]]),line([[25,y-8],[35,y-8],[30,y+2]],closed=True,fill='#333333'),line([[24,y+3],[36,y+3]]),line([[34,y-2],[40,y-9]]),line([[38,y],[44,y-7]]),line([[37,y-9],[40,y-9],[40,y-6]]),line([[41,y-7],[44,y-7],[44,y-4]])]
    s['led-single']=[rect(0,0,100,90),rect(80,5,7,80),line([[100,27],[32,27],[32,66],[100,66]]),line([[25,35],[40,35],[32,49]],closed=True,fill='#333333'),line([[24,50],[41,50]]),line([[20,40],[8,53]],width=2),line([[24,46],[12,59]],width=2),line([[8,47],[8,53],[14,52]]),line([[12,53],[12,59],[18,58]])]
    s['horn']=[ellipse(50,36,45,35),ellipse(50,36,36,27),ellipse(50,36,10,8),rect(18,72,20,27),rect(63,72,20,27),line([[28,60],[28,89]]),line([[73,60],[73,89]])]
    s['speaker']=[rect(0,26,36,46,GREY),line([[36,26],[95,0],[95,100],[36,72]],closed=True,fill='#cccccc')]
    s['capacitor']=[rect(0,0,56,100,GREY),line([[28,0],[28,37]],width=2),line([[10,37],[46,37]],width=3),line([[28,76],[28,100]],width=2),line([[10,76],[14,65],[21,60],[28,58],[36,62],[43,68],[46,76]],width=2),text('+',46,26,13)]
    s['resistor']=[rect(0,0,38,100,GREY),line([[19,0],[19,30]]),zigzag(19,30,22,42,4),line([[19,72],[19,100]])]
    s['flasher']=[rect(0,0,100,60,PALE),line([[12,46],[12,23],[28,13],[47,8],[64,14],[79,24],[92,24]],width=2.5),line([[8,49],[20,49],[20,36],[26,36],[26,44],[33,44],[33,36],[40,36],[40,44],[47,44],[47,36],[54,36],[54,44],[61,44],[61,36],[68,36],[68,44],[75,44],[75,35],[91,35]])]
    s['diode']=[rect(0,0,100,80,GREY),line([[0,40],[32,40]]),line([[64,40],[100,40]]),line([[32,23],[64,40],[32,57]],closed=True,fill='#222222'),line([[66,22],[66,58]],width=2)]
    capsule=[[0,0],[76,0]]+[[76+24*math.cos(-math.pi/2+i*math.pi/64),50+50*math.sin(-math.pi/2+i*math.pi/64)] for i in range(65)]+[[0,100]]
    s['headlamp']=[line(capsule,closed=True,fill=WHITE),line([[16,-30],[16,130]],width=2),line([[19,-30],[19,130]],width=1),line([[0,20],[51,20],[55,68],[71,68]]),line([[0,67],[27,67]]),coil(27,67,23,20,3),coil(71,68,19,20,3),line([[50,67],[53,84],[86,84],[90,68]]),line([[0,92],[53,84]]),ellipse(53,84,2,fill=INK)]
    s['gauge']=[rect(0,0,100,127,GREY),ellipse(51,65,32,32),line([[31,65],[57,65]],'#343434',3),ellipse(32,65,3,fill='#343434'),line([[66,43],[66,87]]),text('F',55,42,8),text('E',55,93,8),rect(77,5,8,15,'none',width=2),line([[76,22],[89,22]],width=2),line([[86,9],[90,12],[90,22],[94,22],[94,9],[90,4]],width=2)]
    for y in [43,52,61,70,79,87]: s['gauge'].append(line([[60,y],[66,y]]))
    s['gauge'][1:1]=[line([[0,39.5],[35,39.5]]),line([[0,63.5],[20,63.5]]),line([[0,86],[35,86]])]
    s['sender']=[rect(0,0,60,66,GREY),line([[21,0],[21,8],[13,8]]),zigzag(13,8,13,42,3),line([[38,0],[38,6],[45,6],[45,27]]),line([[23,16],[70,40]],'#333333',2),line([[23,16],[32,19],[28,25]],closed=True,fill='#333333'),ellipse(45,27,4),ellipse(84,48,17,9),line([[67,39],[74,40]])]
    s['rotor']=[ellipse(50,50,46,46,PALE)]
    for i in range(10):
        a=i*math.pi/5; s['rotor'].append(line([[50+47*math.cos(a-.065),50+47*math.sin(a-.065)],[50+50*math.cos(a-.065),50+50*math.sin(a-.065)],[50+50*math.cos(a+.065),50+50*math.sin(a+.065)],[50+47*math.cos(a+.065),50+47*math.sin(a+.065)]],closed=True,fill=PALE))
    s['ckp']=[rect(0,0,48,100,PALE),rect(-23,34,23,34,PALE),line([[48,15],[24,15]]),line([[48,85],[24,85]]),line([[24+8*(math.cos(t/240*16*math.pi)-1)/2,15+70*t/240-3*math.sin(t/240*16*math.pi)] for t in range(241)])]
    s['ignition-coil']=[rect(0,43,68,54,'#bfc2c4'),rect(6,0,16,27),rect(44,0,16,27),line([[10,15],[10,27],[16,32],[16,43]]),line([[50,15],[50,27],[54,32],[54,43]])]
    s['spark-plug']=[line([[22,0],[45,0],[37,14],[30,14]],closed=True,fill='#bbbbbb'),line([[30,14],[30,35],[22,35],[33,56],[44,35],[37,35],[37,14]],closed=True,fill='#cccccc'),line([[33,63],[22,84],[29,84],[29,100],[37,100],[37,84],[44,84]],closed=True,fill='#cccccc'),line([[20,103],[46,103]]),line([[25,108],[41,108]]),line([[30,113],[36,113]])]
    s['acg']=[ellipse(50,50,49,49,GREY)]
    for ang in [-90,30,150]:
        a=math.radians(ang); pts=[]
        for t in range(121):
            u=12+35*t/120+5*math.sin(t/120*6*math.pi); v=5*(math.cos(t/120*6*math.pi)-1)
            pts.append([50+u*math.cos(a)-v*math.sin(a),50+u*math.sin(a)+v*math.cos(a)])
        s['acg'] += [line(pts),line([[50,50],pts[0]]),ellipse(*pts[-1],4,fill='#292929')]
    s['acg'].append(ellipse(50,50,3,fill='#292929'))
    s['motor']=[ellipse(50,55,36,40,'#c8ccce'),rect(43,0,14,15,'#c8ccce'),ellipse(15,20,10),ellipse(15,20,6),ellipse(85,20,10),ellipse(85,20,6),text('M',50,72,48,bold=False)]
    s['pump']=[ellipse(50,50,48,46,'#c8ccce'),rect(29,0,42,9,'#333333'),rect(29,91,42,9,'#333333'),text('M',50,69,50,bold=False)]
    s['thermistor']=[rect(0,0,100,65,PALE),line([[14,0],[14,37],[32,37]]),line([[85,0],[85,37],[64,37]]),line([[29,37],[34,30],[39,43],[44,30],[49,43],[54,30],[59,43],[64,37]]),line([[32,18],[55,52],[67,52]])]
    s['tp']=[rect(0,0,100,65,PALE),line([[14,0],[14,32],[34,32]]),line([[85,0],[85,32],[66,32]]),line([[50,0],[50,23]]),line([[44,18],[50,26],[56,18]],closed=True,fill='#333333'),line([[32,32],[37,25],[42,39],[47,25],[52,39],[57,25],[62,39],[67,32]])]
    s['oxygen']=[rect(0,0,44,100,PALE),line([[22,0],[22,28]]),zigzag(22,28,15,19,3),line([[22,47],[22,65]]),line([[10,65],[34,65]]),line([[14,70],[30,70]]),line([[22,70],[22,100]]),line([[7,40],[35,19]]),line([[7,40],[11,31]])]
    s['valve']=[rect(0,10,14,40),rect(14,17,16,26,GREY),rect(30,0,55,60,GREY),rect(85,17,15,26,GREY),rect(48,-7,12,7)]
    s['injector']=[rect(0,0,27,20,'#b6c6c9'),line([[27,0],[55,5],[73,41],[48,59],[24,16]],closed=True,fill='#aeb7b8'),line([[50,23],[77,13],[84,24],[58,36]],closed=True,fill='#aeb7b8'),rect(76,11,12,9,'#aaaaaa'),line([[26,23],[12,33],[24,51],[41,42]],closed=True,fill='#aaaaaa')]
    s['switch-contact']=s['switch'][1:]
    s['dimmer']=[dict(e) for e in s['selector']]
    s['dimmer'][4]=line([[32,44],[86,16]],width=2)
    del s['dimmer'][5]
    s['relay-start']=[dict(e) for e in s['relay']]
    s['relay-start'][1]=line([[20,27],[33,12],[78,12]])
    return s
