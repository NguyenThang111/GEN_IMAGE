import json,sys,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from diagram_text import enrich_diagram_text,audit_diagram_text
OUT=ROOT/'review'/'text-repair-2026-10-08'
reports=[]
component_manifest=ROOT/'review/component-repair-2026-10-08/repair-manifest.json'
ready_map={r['file']:r for r in json.loads(component_manifest.read_text('utf-8'))['files']} if component_manifest.exists() else {}
for folder in ['01.AirBlade-2011-2012','SH Mode 2023-2025','Vario 2023 - 2025']:
 for f in sorted((ROOT/'File JSON chuẩn'/folder).glob('[0-9][0-9].*.json')):
  if '.schema.' in f.name:continue
  before=json.loads(f.read_text('utf-8-sig'));d=enrich_diagram_text(before);check=audit_diagram_text(d)
  if check['errors']:raise ValueError(json.dumps({'file':str(f),'errors':check['errors']},ensure_ascii=True))
  backup=OUT/'original-json'/folder/f.name;backup.parent.mkdir(parents=True,exist_ok=True)
  if not backup.exists():shutil.copyfile(f,backup)
  f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  original=json.loads(backup.read_text('utf-8-sig'))
  ready=f;ready_name=f.name.replace('.json','.schema.json')
  if f.relative_to(ROOT).as_posix() in ready_map:
   item=ready_map[f.relative_to(ROOT).as_posix()];ready=component_manifest.parent/item['readyFile'];rd=json.loads(ready.read_text('utf-8'))
   for key in ['components','wires','drawing','annotations']:rd[key]=d[key]
   ready.write_text(json.dumps(rd,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');ready_name=ready.name
  reports.append({'file':f.relative_to(ROOT).as_posix(),'vehicle':folder,'name':f.name,**check,'labelsFilled':sum(not a['label'] and bool(b['label']) for a,b in zip(original['components'],d['components'])),'readyFile':str(ready),'readyName':ready_name})
(OUT/'text-audit.json').write_text(json.dumps({'status':'PASS','files':reports},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'files':len(reports),'labelsFilled':sum(r['labelsFilled'] for r in reports),'texts':sum(r['textCount'] for r in reports),'noteBoxes':sum(len(r['noteBoxes']) for r in reports)},ensure_ascii=True))
