# JSON sửa chữ và ghi chú

34 mạch: AirBlade 2011–2012 (10), SH Mode 2023–2025 (12), Vario 2023–2025 (12).
58 component được bổ sung label; 2.066 mục chữ được giữ ở cả drawing và components/textLayout, wire.labels, annotations. Các khung ghi chú là chữ SVG thật, tiêu đề căn giữa, nội dung căn trái, khoảng đệm 10 px theo font Arial. Giữ nguyên chân, đường dây, mã màu và phần nội dung chưa chắc theo ảnh.

Mở review.html để xem ảnh nguồn và bản dựng từ renderer web. Các folder xe chứa JSON để nạp, source chứa ảnh gốc, preview chứa PNG/SVG. SH Mode và Vario đã dùng ID/tên project trong ảnh chụp. AirBlade 2011–2012 giữ identity của bộ gốc; không dùng bộ này cho AIR BLADE 160 2026.

Trong Diagram Studio: mở circuit → nạp JSON và ảnh gốc tương ứng → kiểm tra → lưu draft. Cần dùng bản code đã sửa trong Desktop/auto2techos và khởi động lại web/API nếu đang chạy. Dữ liệu trên website chưa được thay tự động.

Code thay đổi nằm trong code-patch theo đường dẫn repo. Chữ nhiều dòng dùng tspan, giữ tiếng Việt/ký tự đơn vị và vị trí từng dòng. Tool gen có schema/hướng dẫn giữ danh sách tải và annotations; tests dùng mock, chưa gọi nhà cung cấp AI thật.
