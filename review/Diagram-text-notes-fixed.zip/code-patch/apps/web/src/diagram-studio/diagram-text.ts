import type { ComponentTextLayout, DrawingText } from './contract';
export function splitDiagramText(e: DrawingText) {
 const step=e.lineHeight ?? (e.size ?? 14)*1.3;
 return e.text.split(/\r?\n/).map((text,index)=>({...e,text,y:e.y+index*step}));
}
export function textLayoutLabel(layout: ComponentTextLayout) {
 return layout.texts.flatMap(e=>e.text.split(/\r?\n/)).join('\n');
}
