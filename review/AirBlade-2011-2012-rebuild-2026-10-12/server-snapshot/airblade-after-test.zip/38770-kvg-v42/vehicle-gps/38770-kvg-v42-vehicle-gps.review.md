# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-vehicle-gps.source.png)

## Files

- Schema: `./38770-kvg-v42-vehicle-gps.schema.json`
- Source image: `./38770-kvg-v42-vehicle-gps.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/vehicle-gps/38770-kvg-v42-vehicle-gps.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-vehicle-gps`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch điện xác định vị trí xe
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 21
- Wires: 25

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm duyệt; tọa độ theo ảnh gốc 1687×952, cần rà soát sai số vài pixel ở mép symbol và tâm dây.
- Hình mặt đầu nối 10P ở góc dưới phải là hình tham chiếu thứ tự chân, không được tạo thành một đầu nối điện độc lập hoặc nối dây suy đoán.
- Đầu nối trên hộp định vị được gộp trong bounds của hộp; terminal đặt tại điểm dây chạm mép trên đầu nối, đối chiếu với số chân nhìn thấy bên dưới. Không tạo chân 9 vì không thấy điểm dây tương ứng.
- Hai nhánh chữ T trên đường R được thể hiện nối liền rõ trong ảnh và được biểu diễn bằng junction; không tạo junction tại các giao cắt không có dấu nối, đặc biệt giao giữa P/Bl và Gr.
- ECM chỉ có một điểm dây chạm nhìn thấy; không suy đoán số chân, chức năng chân hoặc các kết nối khác.

## Uncertain items / điểm chưa chắc chắn

- Không có

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
