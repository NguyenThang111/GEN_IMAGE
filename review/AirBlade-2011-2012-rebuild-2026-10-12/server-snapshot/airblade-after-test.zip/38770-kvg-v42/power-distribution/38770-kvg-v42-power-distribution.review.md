# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-power-distribution.source.png)

## Files

- Schema: `./38770-kvg-v42-power-distribution.schema.json`
- Source image: `./38770-kvg-v42-power-distribution.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/power-distribution/38770-kvg-v42-power-distribution.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-power-distribution`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch cấp nguồn
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 22
- Wires: 24

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm duyệt đối chiếu. Tọa độ đã quy về hệ pixel 2998×1688; bounds và điểm chạm dây được ước lượng từ ảnh.
- Không nối giao cắt tại khoảng (804, 697): dây R/W từ cầu chì MAIN xuống chỉnh lưu cắt dây R/Bl từ cầu chì FI nhưng không có chấm nối.
- Các nhánh chữ T liên tục, nhìn rõ được biểu diễn bằng junction; không coi các đường giao cắt đơn thuần là điểm nối.
- Các danh sách thiết bị bằng chữ và ngoặc phân nhánh không phải symbol hay terminal thực. Không tạo linh kiện hoặc pin từ các danh sách này.
- Chưa đưa vào wires đoạn P/Bl sau cầu chì ANSWER BACK, đoạn Y sau cầu chì HEAD LIGHT, đoạn Bl/Br sau cầu chì TURN,HORN và nhánh Bl đi xuống danh sách tải: ảnh không có terminal thực ở đầu đích để nối.
- ECM chỉ có một điểm chạm dây W/Bl nhìn thấy ở cạnh trên; không suy đoán thêm chân cấp nguồn từ chữ ECM trong danh sách tải.
- Tụ điện và tiết chế/chỉnh lưu dùng type device vì bộ symbol cho phép không có loại riêng tương ứng. Không dựng các cuộn dây nội bộ ACG thành dây ngoài.

## Uncertain items / điểm chưa chắc chắn

- Hai dây Y ở hai bên ACG bị phần hình tròn của symbol che một phần. Đường đi đến các chấm cực dưới trái/phải cần kiểm tra lại; các đoạn khuất được biểu diễn thẳng theo hướng dây nhìn thấy.
- Nhánh tụ điện có mã R/Bl phía trên chấm nối và R/W phía dưới; bản nháp giữ nguyên sự đổi mã thể hiện trong ảnh, không tự sửa.
- Các chân rơ le, chỉnh lưu, ACG và ECM không có số pin đọc được. ID terminal chỉ mô tả vị trí, không phải số chân của nhà sản xuất.
- Các mã màu nhìn thấy ở đoạn chưa dựng: P/Bl = hồng/đen, Y = vàng, Bl/Br = đen/nâu, Bl = đen. Chưa tạo wire cho các đoạn này vì thiếu terminal đích.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
