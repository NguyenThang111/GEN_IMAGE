# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-pgm-fi.source.png)

## Files

- Schema: `./38770-kvg-v42-pgm-fi.schema.json`
- Source image: `./38770-kvg-v42-pgm-fi.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/pgm-fi/38770-kvg-v42-pgm-fi.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-pgm-fi`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Hệ thống phun xăng điện tử PGM-FI
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 38
- Wires: 56

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm duyệt đối chiếu; toàn bộ tọa độ dùng hệ pixel ảnh gốc 1687×952.
- Không tạo thêm một ECM hoặc giắc điện từ hình tra cứu đầu nối 33P ở bên phải; hình này không có dây nối vào.
- Chưa dựng dây R từ cực dương ắc quy đến tiếp điểm rơ le khởi động: đoạn dây gần cực dương có nét xiên và vùng chồng nét cần kiểm tra.
- Chưa dựng đường cao áp mô-bin–bugi và các dây PG1/PG2 đến mass: ảnh thể hiện đoạn xiên, không thay bằng đường gấp khúc suy đoán.
- Đầu nối SCS phía dưới DLC được giữ như hình rời; không suy đoán trạng thái cắm, chân tiếp xúc hoặc nối tắt với DLC.
- Các tuyến dùng chung dây nguồn được biểu diễn bằng những wire có đoạn trùng nhau và cùng terminal nguồn; không thêm junction tại chỗ chỉ giao cắt.
- Không thêm chân mass cho cảm biến ôxy hoặc chân chưa thấy rõ trên bugi.

## Uncertain items / điểm chưa chắc chắn

- Vị trí hai điểm tiếp xúc ở kim phun nhỏ và hơi mờ; cần kiểm tra lại terminal tại (819,337) và (819,350).
- Các nhãn chân ECM 11 IGP-LS và 22 FIWARN được đọc từ chữ nhỏ; cần đối chiếu ảnh độ phân giải cao hơn.
- Mã R/Bl trên nhánh công tắc máy–tụ điện và R/W sát tụ điện khác nhau như chữ thể hiện trong ảnh; chưa suy đoán nguyên nhân hoặc vị trí đổi màu dây.
- Bounds bugi bao gồm hình điện cực/mass liền kề vì nét biểu tượng khó tách; chưa tạo terminal cho biểu tượng này.
- Các nhánh G/Y của công tắc phanh và G/O của cảm biến IAT là chỗ rẽ dây nhìn thấy, nhưng không có chấm junction đủ rõ; cần kiểm duyệt topology tại (1420,330) và (698,687).
- Giá trị hex là màu quy ước theo mã dây, không phải màu đo trực tiếp từ ảnh.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
