# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-night-lighting.source.png)

## Files

- Schema: `./38770-kvg-v42-night-lighting.schema.json`
- Source image: `./38770-kvg-v42-night-lighting.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/night-lighting/38770-kvg-v42-night-lighting.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-night-lighting`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch đèn đêm
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 42
- Wires: 42

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm duyệt; tọa độ theo ảnh gốc 1687×952.
- Không nối giao cắt tại khoảng (529, 412): dây R/W đi dọc và dây R/Bl đi ngang không có chấm junction.
- Các danh sách tải bên phải chỉ có chữ và đường dẫn, không có symbol hoặc terminal thiết bị rõ ràng. Không tạo linh kiện hay dây nối đến terminal giả cho các tải này.
- Chưa đưa vào wires đoạn P/Bl sau cầu chì ANSWER BACK, đoạn Y sau cầu chì HEAD LIGHT, đoạn Bl/Br sau cầu chì TURN, HORN và nhánh Bl từ (856, 412) xuống danh sách tải phía dưới vì không thấy terminal đích thật.
- Chữ ECM trong danh sách tải phía dưới không được coi là một symbol ECM thứ hai và không được nối suy đoán vào hộp ECM đã vẽ.
- ECM chỉ được tạo một terminal tại điểm dây W/Bl chạm hộp; ảnh không thể hiện số pin.
- Các nút rẽ chữ T được ghi nhận tại vị trí nét dây hợp nhánh rõ; không tạo junction cho các đường chỉ giao cắt.

## Uncertain items / điểm chưa chắc chắn

- Bounds và điểm chạm dây được ước lượng từ nét ảnh, cần kiểm tra sai số vài pixel.
- Các mã Bl và P/Bl có ký tự l nhỏ dễ nhầm với I; bản nháp đọc là Bl theo ký hiệu in trên ảnh.
- Điểm màu đỏ gần (672, 460) được biểu diễn là junction chuyển đoạn có nhãn R/Bl sang R/W; ảnh không chỉ rõ đây có phải giắc nối vật lý hay không.
- Các terminal không có số chân trong ảnh dùng ID mô tả vị trí hoặc chức năng, không phải số pin do nhà sản xuất công bố.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
