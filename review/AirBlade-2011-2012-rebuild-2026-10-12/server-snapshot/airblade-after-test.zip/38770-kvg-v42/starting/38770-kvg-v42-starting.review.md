# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-starting.source.png)

## Files

- Schema: `./38770-kvg-v42-starting.schema.json`
- Source image: `./38770-kvg-v42-starting.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/starting/38770-kvg-v42-starting.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-starting`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch khởi động
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 26
- Wires: 32

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Non-orthogonal wire segment: w-starter-feed
- Non-orthogonal wire segment: w-battery-motor
- Non-orthogonal wire segment: w-battery-motor
- Non-orthogonal wire segment: w-motor-lug-ground

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm duyệt đối chiếu, không phải sơ đồ đã xác nhận dùng cho sửa chữa hoặc đấu dây.
- Tọa độ theo ảnh gốc 1687×952; bounds và điểm chạm dây được ước lượng từ nét ảnh, có thể lệch vài pixel.
- Các đoạn dây chéo gần cực ắc quy và hai tai mô tơ được biểu diễn bằng đường gấp khúc ngang/dọc theo yêu cầu; đường đi tại đó không trùng hoàn toàn nét ảnh.
- Ngoài chấm nối xanh tại (1412,498), các junction còn lại biểu diễn những chỗ phân nhánh có nét dây nhập liền nhìn thấy rõ, không phải các giao cắt độc lập.
- Chỉ tạo năm chân ECM nhìn thấy: 33, 1, 7, 29 và 25; không bổ sung chân hoặc kết nối ngoài ảnh.
- Điện trở được dùng symbol device vì danh sách symbol cho phép không có resistor.

## Uncertain items / điểm chưa chắc chắn

- w-resistor-ground và w-motor-ground không có mã màu dây đọc được; để code rỗng và dùng #4b5563, không suy diễn nét đen thành mã Bl.
- Vị trí chính xác của điểm tách dây R gần cực dương ắc quy bị nét dây dày che lẫn; j-red-starter đặt xấp xỉ tại (300,336), cần kiểm tra lại.
- Hai tai bên mô tơ có dây G và G/W chạm rõ, nhưng ảnh không ghi tên hay chức năng riêng; left-lug và right-lug chỉ là định danh hình học, không khẳng định cấu tạo điện bên trong.
- Các giá trị hex là màu đại diện cho mã màu đọc trên ảnh, không phải phép đo màu dây thực tế.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
