# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-ignition.source.png)

## Files

- Schema: `./38770-kvg-v42-ignition.schema.json`
- Source image: `./38770-kvg-v42-ignition.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/ignition/38770-kvg-v42-ignition.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-ignition`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch đánh lửa
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 17
- Wires: 20

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Non-orthogonal wire segment: w-green-ground
- Non-orthogonal wire segment: w-ecm-10-ground

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm tra đối chiếu; tọa độ theo ảnh gốc 1687×952.
- Tụ điện dùng symbol device vì danh sách symbol cho phép không có capacitor.
- Hai đoạn dây chéo gần mass ECM được chuyển thành đường bậc thang ngang/dọc; các điểm trung gian này không trùng hoàn toàn nét dây trong ảnh.
- Nhánh dây Bl tại (994,243) là chỗ nối chữ T liền nét, không phải giao cắt độc lập.
- Chỉ tạo tám chân ECM có số và điểm chạm dây nhìn thấy; không bổ sung chân hoặc giắc không được thể hiện.
- Rôto cạnh CKP chỉ được ghi nhận hình học, không tạo kết nối điện với cảm biến.

## Uncertain items / điểm chưa chắc chắn

- Vùng hội tụ dây tại (1294,695) nằm rất gần vòng tròn đầu mass: cần kiểm tra lại ranh giới giữa điểm hội tụ và terminal mass; đoạn w-ground-terminal không có mã màu đọc được nên dùng #4b5563.
- Ranh giới mô-bin và đầu bugi tại y=530–534 khá sát nhau; cần kiểm tra lại bounds và terminal cao áp. Đoạn w-coil-plug không có mã màu nên dùng #4b5563.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
