# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-horn.source.png)

## Files

- Schema: `./38770-kvg-v42-horn.schema.json`
- Source image: `./38770-kvg-v42-horn.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/horn/38770-kvg-v42-horn.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-horn`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch còi
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 12
- Wires: 12

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm tra đối chiếu; tọa độ đã quy về ảnh gốc 2998×1688, có thể sai lệch vài pixel tại nét dày và viền symbol.
- ECM chỉ có một điểm dây chạm rõ ở cạnh trên; ảnh không ghi tên hoặc số chân nên để nhãn terminal là null, không bổ sung chân khác.
- Junction nguồn R biểu diễn nhánh chữ T liền nét nhìn thấy trước hai cầu chì MAIN và FI; không bổ sung nút nối tại vị trí khác.
- Các góc dây bo tròn được biểu diễn bằng đoạn ngang/dọc. Màu hex là màu đại diện theo mã dây và màu nhìn thấy, không phải phép đo màu chính xác.

## Uncertain items / điểm chưa chắc chắn

- Không có

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
