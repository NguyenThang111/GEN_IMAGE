# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-brake-light.source.png)

## Files

- Schema: `./38770-kvg-v42-brake-light.schema.json`
- Source image: `./38770-kvg-v42-brake-light.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/brake-light/38770-kvg-v42-brake-light.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-brake-light`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch đèn phanh
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 18
- Wires: 19

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm tra rà soát; tọa độ theo ảnh gốc 1687×952, có thể lệch vài pixel do nét dây dày.
- Chỉ ghi nhận một điểm dây chạm ECM nhìn thấy ở cạnh trên; ảnh không ghi số chân nên không bổ sung pin hoặc chức năng chân.
- Cụm đèn được biểu diễn bằng một lamp với hai điểm dây ngoài nhìn thấy; không suy đoán chân đèn hậu riêng hoặc đấu nối LED bên trong.
- Điện trở dùng type device vì danh sách symbol cho phép không có resistor.
- Các điểm rẽ chữ T tại (340,394) và (1254,392) được ghi nhận theo nhánh dây liền nét, không phải giao cắt hai dây độc lập.

## Uncertain items / điểm chưa chắc chắn

- Dây từ điện trở xuống mass có màu xanh lá nhưng không thấy nhãn mã màu; để code rỗng, không tự gán G.
- Trị số điện trở đọc là 10Ω 20W; chữ nhỏ cần đối chiếu lại trên ảnh rõ hơn.
- Các giá trị hex biểu diễn màu dây, không phải màu được đo chính xác từ ảnh.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
