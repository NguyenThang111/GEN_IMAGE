# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-turn-signals.source.png)

## Files

- Schema: `./38770-kvg-v42-turn-signals.schema.json`
- Source image: `./38770-kvg-v42-turn-signals.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/turn-signals/38770-kvg-v42-turn-signals.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-turn-signals`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch xi nhan
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 16
- Wires: 16

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm tra; tọa độ theo ảnh gốc 1687×952, có thể lệch vài pixel do nét dây dày.
- ECM chỉ có một điểm dây chạm nhìn thấy ở cạnh trên; ảnh không ghi số hoặc tên chân nên không bổ sung pin khác.
- Tên tải sau cầu chì 10A chỉ đọc được TURN, HORN…; không suy đoán phần còn lại hoặc thêm còi.
- Không tạo dây liên kết giữa các ký hiệu mass riêng biệt vì ảnh không vẽ các đoạn dây đó.

## Uncertain items / điểm chưa chắc chắn

- junction-power tại (335,447) được ghi nhận theo nhánh chữ T màu đỏ liền nét; không thấy chấm nối riêng, cần kiểm tra lại khi duyệt.
- Các giá trị hex là màu đại diện theo mã dây, không phải kết quả đo màu chính xác từ ảnh.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
