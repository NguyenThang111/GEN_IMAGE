# Diagram draft review

![Ảnh sơ đồ gốc](./38770-kvg-v42-fuel-indicator.source.png)

## Files

- Schema: `./38770-kvg-v42-fuel-indicator.schema.json`
- Source image: `./38770-kvg-v42-fuel-indicator.source.png`
- EasyScan target: `src/v4/components/ElectricalDiagram/packs/38770-kvg-v42/fuel-indicator/38770-kvg-v42-fuel-indicator.schema.json`

## Draft summary

- Diagram ID: `38770-kvg-v42-fuel-indicator`
- Vehicle ID: `38770-kvg-v42`
- Vehicle: AIR BLADE 2011 - 2012
- Circuit: Mạch báo xăng
- ECM ID: 01 00 F9
- Model: gpt-6-astra
- Review status: `draft`
- Components: 13
- Wires: 14

> ECM ID hiện là metadata của hồ sơ review, chưa thuộc EasyScan F01 runtime schema. Structural validation không chứng minh topology điện đúng. Bắt buộc human review trước khi đưa vào catalog.

## Validator errors

- Không có

## AI warnings / phần còn thiếu

- Đây là bản nháp để người kiểm duyệt; tọa độ dùng hệ pixel ảnh gốc 1687×952, có thể lệch vài pixel do độ dày nét.
- ECM chỉ có một điểm dây chạm nhìn thấy ở cạnh trên; không bổ sung hoặc suy đoán các chân khác.
- Không có số chân đọc được trên rơ le, ECM, đồng hồ và phao xăng; các ID terminal chỉ dùng để định danh vị trí, không phải số chân thực tế.
- Hai junction biểu diễn các nhánh chữ T có nét dây nối liền rõ trong ảnh; không biểu diễn thêm kết nối mass hay dây ngoài phạm vi ảnh.

## Uncertain items / điểm chưa chắc chắn

- Hai nhánh chữ T tại (341, 288) và (1367, 442) không có chấm junction tròn riêng; cần xác nhận lại cách biểu diễn nút nối khi duyệt.

## Human review checklist

- [ ] Đối chiếu đủ component với ảnh nguồn.
- [ ] Đối chiếu terminal/pin; không suy đoán pin bị che hoặc không đọc được.
- [ ] Đối chiếu từng wire endpoint, junction/crossing và mã màu dây.
- [ ] Sửa các validator errors có ý nghĩa trước khi nâng review status.
- [ ] Chỉ đánh dấu electrically-reviewed sau khi người có chuyên môn duyệt điện.
