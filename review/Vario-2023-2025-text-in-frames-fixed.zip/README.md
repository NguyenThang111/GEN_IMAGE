# Vario 2023–2025 · sửa chữ trong khung

12 JSON đã giữ đầy đủ chữ, số chân, ký hiệu và hình trong các cụm. Không đổi terminal, mã chân, vị trí dây hoặc màu dây. Renderer mới tự tách các dòng ghi chú của JSON cũ và đặt chữ trong khung; hiển thị nhãn chân hai phía ECM/SCU/cụm đồng hồ thay vì dồn bên dưới. Khung ghi chú giữ tiêu đề căn giữa và mỗi dòng nội dung căn trái.

Source code tại C:/Users/thang/Desktop/auto2techos đã được cập nhật. Khi web đang chạy bản build cũ, cần build lại và tải lại trang. code-patch chứa các file theo đường dẫn repo. JSON trong folder xe có identity đúng project Vario; source là ảnh gốc. Nạp JSON tương ứng khi project đang giữ bản dữ liệu cũ thiếu chữ.

Mở review.html để xem kết quả. vario-note-pin-check.png đối chiếu khung ghi chú và chân 3 HIGH BEAM với ảnh gốc. Kiểm tra 12 mạch, 136 nhãn chân có số; 319 kiểm thử web đạt, TypeScript và build đạt. Chưa thay dữ liệu trong cơ sở dữ liệu của website.
